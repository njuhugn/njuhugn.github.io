import time
from collections import defaultdict

start_time = time.time()

feat_ids = defaultdict(int)
id_feats = defaultdict(str)
ufeat_ids = defaultdict(int)
ifeat_ids = defaultdict(int)
id_ufeats = defaultdict(str)
id_ifeats = defaultdict(str)
with open('feat_ids_map.libfm') as ifile:
    for line in ifile:
        line = line.strip()
        if not line:
            continue
        line = line.split(':')
        if len(line) != 2:
            continue
        feat_name = line[0]
        feat_id = int(line[1])
        feat_ids[feat_name] = feat_id
        id_feats[feat_id] = feat_name
        if feat_name[0] == 'u':
            ufeat_ids[feat_name] = feat_id
            id_ufeats[feat_id] = feat_name
        elif feat_name[0] == 'i':
            ifeat_ids[feat_name] = feat_id
            id_ifeats[feat_id] = feat_name
print('#map(user,item,feat) = {}, {}, {}'.format(len(ufeat_ids), len(ifeat_ids), len(feat_ids)))

user_apps_train = defaultdict(set)
app_users_train = defaultdict(set)
ntrain = 0
with open('user_apps_0_train_bin.libfm') as ifile:
    for line in ifile:
        line = line.strip()
        if not line:
            continue
        line = line.split(' ')
        label = int(line[0])
        if label != 1 or len(line) < 3:
            continue

        # user
        fid_val = line[1].split(':')
        fid = int(fid_val[0])
        fname = id_feats[fid]
        uid = ufeat_ids[fname]
        # item
        fid_val = line[2].split(':')
        fid = int(fid_val[0])
        fname = id_feats[fid]
        iid = ifeat_ids[fname]

        user_apps_train[uid].add(iid)
        app_users_train[iid].add(uid)
        ntrain += 1
print('#train(user,item,feat)={}, {}, {}'.format(len(user_apps_train), len(app_users_train), ntrain))

user_apps_test = defaultdict(set)
app_users_test = defaultdict(set)
ntest = 0
with open('user_apps_0_test_bin_wo_AUC.libfm') as ifile:
    for line in ifile:
        line = line.strip()
        if not line:
            continue
        line = line.split(' ')
        label = int(line[0])
        if label != 1 or len(line) < 3:
            continue

        # user
        fid_val = line[1].split(':')
        fid = int(fid_val[0])
        fname = id_feats[fid]
        uid = ufeat_ids[fname]
        # item
        fid_val = line[2].split(':')
        fid = int(fid_val[0])
        fname = id_feats[fid]
        iid = ifeat_ids[fname]

        user_apps_test[uid].add(iid)
        app_users_test[iid].add(uid)
        ntest += 1
print('#test(user,item,feat)={}, {}, {}'.format(len(user_apps_test), len(app_users_test), ntest))

with open('user_apps_0.libfm.train', 'w', encoding='utf-8') as ofile:
    for user, apps in user_apps_train.items():
        ofile.write(str(user) + ' ' + str(len(apps)) + ' ' + ' '.join([str(a) for a in apps]) + '\n')

with open('user_apps_0.libfm.test', 'w', encoding='utf-8') as ofile:
    for user, apps in user_apps_test.items():
        ofile.write(str(user) + ' ' + str(len(apps)) + ' ' + ' '.join([str(a) for a in apps]) + '\n')

print('--- {} min ---'.format((time.time()-start_time) / 60))  # about 13 mins
