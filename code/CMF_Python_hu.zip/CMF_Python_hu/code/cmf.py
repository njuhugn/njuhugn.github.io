import numpy
import time
import scipy.sparse
import sys
import itertools
from collections import defaultdict


class CMF:
    metaFile = ''
    trainDataFile = ''
    testDataFile = ''
    pred_file = ''
    # settings
    rc_schema = numpy.array([[0, 0], [1, 2]])  # same order of data matrices
    C = 0.1
    K = 50
    T = 100  # number of iterations
    r0s = [1.0, 0.0]
    r1s = [5.0, 1.0]
    tol = 0.0001  # change
    S = 3  # number of types/relations, e.g., 0:user, 1:item, 2:context
    Ns = list()  # sizes of each type
    modes = numpy.zeros(2, object)
    modes[0] = 'sparsemf'  # sparse or dense or log
    modes[1] = 'sparsemf'
    # info in metadata
    numAttrPerGroup = defaultdict(set)
    user_featureIDs_set = set()
    item_featureIDs_set = set()
    context_featureIDs_set = set()
    numAttributes = 0
    numUsers = 0
    numItems = 0
    numContexts = 0
    # info in traindata
    nTrainPosExamples = 0
    nTrainNegExamples = 0
    nTrainExamples = 0
    user_item_train = scipy.sparse.csc_matrix((numUsers, numItems), dtype=float)
    user_context_train = scipy.sparse.csc_matrix((numUsers, numContexts), dtype=float)
    # info in testdata
    nTestPosExamples = 0
    nTestNegExamples = 0
    nTestExamples = 0
    user_item_test = scipy.sparse.csc_matrix((numUsers, numItems), dtype=float)

    def __init__(self, metaFile, trainDataFile, testDataFile, C, K, T, alphas, step):
        self.C = C
        self.K = K
        self.T = T
        self.alphas = alphas
        self.step = step
        print(self.alphas)
        self.metaFile = metaFile
        self.trainDataFile = trainDataFile
        self.testDataFile = testDataFile

    def loadMetaData(self):
        with open(self.metaFile) as ifile:
            for line in ifile:
                line = line.strip()
                if not line:
                    continue
                line = line.split(':')
                fstr = line[0]
                fid = int(line[1])
                type = fstr[0]
                if type == 'u':
                    self.numUsers += 1
                    self.user_featureIDs_set.add(fid)
                elif type == 'i':
                    self.numItems += 1
                    self.item_featureIDs_set.add(fid)
                else:
                    self.numContexts += 1
                    self.context_featureIDs_set.add(fid)
                self.numAttrPerGroup[type].add(fid)
                self.numAttributes += 1
        print('numAttrGroups = ' + str(len(self.numAttrPerGroup)))
        print('numAttributes = ' + str(self.numAttributes))
        print('#(user,item,context) = {},{},{}'.format(self.numUsers, self.numItems, self.numContexts))

    def loadTrainData(self):
        user_item = numpy.zeros(shape=(self.numUsers, self.numItems))
        user_context = numpy.zeros(shape=(self.numUsers, self.numContexts))
        with open(self.trainDataFile) as ifile:
            for line in ifile:
                line = line.strip()
                if not line:
                    continue
                line = line.split(' ')
                label = int(line[0])
                if label > 0:
                    self.nTrainPosExamples += 1
                else:
                    self.nTrainNegExamples += 1
                self.nTrainExamples += 1
                ufid_ufval = line[1].split(':')
                ufid = int(ufid_ufval[0])
                #ufval = float(ufid_ufval[1])
                ifid_ifval = line[2].split(':')
                ifid = int(ifid_ifval[0])
                #ifval = float(ifid_ifval[1])
                user_item[ufid][ifid-self.numUsers] = label
                for cfid_cfval in line[3:]:
                    cfid_cfval = cfid_cfval.split(':')
                    cfid = int(cfid_cfval[0])
                    cfval = float(cfid_cfval[1])
                    user_context[ufid][cfid-self.numUsers-self.numItems] = cfval  # repeat exc |Iu| times
                if self.nTrainExamples % 500000 == 0:
                    sys.stdout.write('.')
        print('\n#nTrain(pos,neg,total) = {},{},{}'.format(self.nTrainPosExamples, self.nTrainNegExamples, self.nTrainExamples))
        self.user_item_train = scipy.sparse.csc_matrix(user_item, dtype=float)
        self.user_context_train = scipy.sparse.csc_matrix(user_context, dtype=float)
        print('#user_item train pairs = ' + str(len(self.user_item_train.data)))
        print('#user_context train pairs = ' + str(len(self.user_context_train.data)))
        self.Xs_trn = [self.user_item_train, self.user_context_train]  # all matrix of training data: Xs

    def loadTestData(self):
        user_item = numpy.zeros(shape=(self.numUsers, self.numItems))
        with open(self.testDataFile) as ifile:
            for line in ifile:
                line = line.strip()
                if not line:
                    continue
                line = line.split(' ')
                label = int(line[0])
                if label > 0:
                    self.nTestPosExamples += 1
                else:
                    self.nTestNegExamples += 1
                self.nTestExamples += 1
                ufid_ufval = line[1].split(':')
                ufid = int(ufid_ufval[0])
                #ufval = float(ufid_ufval[1])
                ifid_ifval = line[2].split(':')
                ifid = int(ifid_ifval[0])
                #ifval = float(ifid_ifval[1])
                user_item[ufid][ifid-self.numUsers] = label
                if self.nTrainExamples % 2000000 == 0:
                    sys.stdout.write('.')
        print('\n#nTest(pos,neg,total) = {},{},{}'.format(self.nTestPosExamples, self.nTestNegExamples, self.nTestExamples))
        self.user_item_test = scipy.sparse.csc_matrix(user_item, dtype=float)
        print('#user_item test pairs = ' + str(self.user_item_test.count_nonzero()))

    def learn(self):
        assert(self.rc_schema.shape[1] == len(self.Xs_trn) and self.rc_schema.shape[0] == 2)  # schema match data
        assert(numpy.all(self.rc_schema[0, :] != self.rc_schema[1, :]))  # should not have symmetric relations
        assert(self.r0s is not None and self.r1s is not None)
        assert(self.alphas is not None)
        self.Xts_trn = numpy.empty(len(self.Xs_trn), object)
        for i in range(len(self.Xs_trn)):
            self.Xts_trn[i] = scipy.sparse.csc_matrix(self.Xs_trn[i].T)  # what's 'T'? Transpose!!
            if self.modes[i] == 'sparselogmf' or self.modes[i] == 'denselogmf':
                assert self.r0s[i] != self.r1s[i]
        self.rel_config()
        print('number of types = ' + str(self.S))
        sys.stdout.write('sizes of each type: ')
        print(self.Ns)
        # random initialize factor matrices
        self.Us = numpy.empty(self.S, object)
        sys.stdout.write('the shape of factor/parameter matrices Us: ')
        print(self.Us.shape)
        for i in range(self.S):
            self.Us[i] = numpy.random.rand(self.Ns[i], self.K) / self.K
        i = 0
        step = self.step
        while i < self.T:
            i += 1
            tic = time.time()
            change = 0
            for t in range(self.S):  # update each matrix in-turn
                change += self.update(t, step)
            change /= numpy.sum(self.Ns)
            toc = time.time()
            print("iter {},  change {:0.4f}, time {:0.4f}(s)".format(i, change, toc - tic))
            if change < self.tol:
                print("Early terminate at iter={} due to insufficient change!".format(i))
                break

    def update(self, t, step):  # update each matrix in-turn
        assert (t <= len(self.Ns) and t >= 0)
        eyeK = self.C * numpy.eye(self.K, self.K)
        N = self.Ns[t]  # number of instances for type t
        V = self.Us[t]
        A = numpy.zeros((self.K, self.K))  # place holders for hessian
        b = numpy.zeros(self.K)  # place holders for gradient
        UtUs = numpy.empty(len(self.Xs_trn), object)
        change = 0
        for j in range(len(self.Xs_trn)):
            if self.modes[j] == 'densemf':
                if self.rc_schema[0, j] == t:
                    U = self.Us[self.rc_schema[1, j]]
                else:
                    U = self.Us[self.rc_schema[0, j]]
                UtUs[j] = numpy.dot(U.T, U)
        for i in range(N):
            A[:] = 0
            b[:] = 0
            for j in range(len(self.Xs_trn)):
                if self.alphas[j] == 0:
                    continue
                if self.rc_schema[0, j] == t or self.rc_schema[1, j] == t:
                    if self.rc_schema[0, j] == t:
                        X = self.Xts_trn[j]
                        U = self.Us[self.rc_schema[1, j]]
                    else:
                        X = self.Xs_trn[j]
                        U = self.Us[self.rc_schema[0, j]]
                    data = X.data
                    indptr = X.indptr
                    indices = X.indices
                    ind_i0, ind_i1 = (indptr[i], indptr[i + 1])
                    if ind_i0 == ind_i1:
                        continue
                    inds_i = indices[ind_i0:ind_i1]
                    data_i = data[ind_i0:ind_i1]
                    if self.modes[j] == "densemf":  # square loss, dense binary representation
                        UtU = UtUs[j]
                        Utemp = U[inds_i, :]
                        A += self.alphas[j] * UtU
                        b += self.alphas[j] * (numpy.dot(UtU, V[i, :]) - numpy.dot(data_i, Utemp))
                    elif self.modes[j] == "denselogmf":  # logistic loss
                        Xi = numpy.dot(U, V[i, :])
                        Yi = - 1 * numpy.ones(U.shape[0])
                        Yi[inds_i] = 1
                        # (sigma(yx)-1)
                        Wi = 1.0 / (1 + numpy.exp(-1 * numpy.multiply(Yi, Xi))) - 1
                        Wi = numpy.multiply(Wi, Yi)
                        gv = numpy.dot(Wi, U)
                        # compute sigmoid(x)
                        Ai = 1 / (1 + numpy.exp(-Xi))
                        Ai = numpy.multiply(Ai, 1 - Ai)
                        Ai = Ai.reshape(Ai.size, 1)
                        AiU = numpy.multiply(Ai, U)
                        Hv = numpy.dot(AiU.T, U)
                        A += self.alphas[j] * Hv
                        b += self.alphas[j] * gv
                    elif self.modes[j] == "sparsemf":  # square loss
                        Utemp = U[inds_i, :]
                        UtU = numpy.dot(Utemp.T, Utemp)
                        A += self.alphas[j] * UtU
                        b += self.alphas[j] * (numpy.dot(UtU, V[i, :]) - numpy.dot(data_i, Utemp))
                    elif self.modes[j] == "sparselogmf":  # sparse logistic loss, sparse representation
                        if self.r1s[j] != self.r0s[j]:
                            Xi = (data_i - self.r0s[j]) / (self.r1s[j] - self.r0s[j])
                        else:
                            Xi = data_i
                        Ui = U[inds_i, :]
                        Yi = numpy.dot(Ui, V[i, :])
                        # sigmoid(Y)
                        Wi = 1.0 / (1 + numpy.exp(-Yi))
                        b += self.alphas[j] * numpy.dot(Wi - Xi, Ui)
                        Wi = numpy.multiply(Wi, 1 - Wi)
                        UiW = numpy.multiply(Wi.reshape(Wi.size, 1), Ui)
                        A += self.alphas[j] * numpy.dot(UiW.T, Ui)
                    else:
                        assert False, "Unrecognized mode: %s" % self.modes[j]
            A += eyeK
            b += self.C * V[i, :]
            d = numpy.dot(numpy.linalg.inv(A), b)
            vi = V[i, :].copy()
            V[i, :] -= step * d
            change += numpy.linalg.norm(vi - V[i, :]) / (numpy.linalg.norm(vi) + 1e-10)
        return change

    def rel_config(self):
        self.S = self.rc_schema.max() + 1  # S : number of entity types
        sys.stdout.write('S = (rc_schema.max() + 1) = ')
        print(self.S)
        self.Ns = -1 * numpy.ones(self.S, int)  # Ns :  number of instances for each entity type
        for i in range(len(self.Xs_trn)):
            sys.stdout.write('In the ' + str(i) + ' turn, the Ns is: ')
            print(self.Ns)
            ri = self.rc_schema[0, i]  # numpy.array([[0, 1, 0], [1, 2, 2]])
            ci = self.rc_schema[1, i]
            [m, n] = self.Xs_trn[i].shape  # user(0) x item(1); item(1) x context(2); user(0) x context(2)
            sys.stdout.write('Xs[' + str(i) + '].shape: ')
            print(self.Xs_trn[i].shape)
            if self.Ns[ri] < 0:
                self.Ns[ri] = m
            else:
                assert(self.Ns[ri] == m)
            if self.Ns[ci] < 0:
                self.Ns[ci] = n
            else:
                assert(self.Ns[ci] == n)

    def predict(self, pred_file):
        i = 0  # only test the first matrix: user x item
        X = self.user_item_test
        if X is None:
            return None
        ri = self.rc_schema[0, i]
        ci = self.rc_schema[1, i]
        U = self.Us[ri]
        V = self.Us[ci]
        r0 = self.r0s[i]
        r1 = self.r1s[i]
        self.nTestPosExamples = 0
        self.nTestNegExamples = 0
        self.nTestExamples = 0
        with open(self.testDataFile, 'r') as ifile:
            with open(pred_file, 'w', encoding='utf-8') as ofile:
                for line in ifile:
                    line = line.strip()
                    if not line:
                        continue
                    line = line.split(' ')
                    label = int(line[0])
                    if label > 0:
                        self.nTestPosExamples += 1
                    else:
                        self.nTestNegExamples += 1
                    self.nTestExamples += 1
                    ufid_ufval = line[1].split(':')
                    ufid = int(ufid_ufval[0])
                    # ufval = float(ufid_ufval[1])
                    ifid_ifval = line[2].split(':')
                    ifid = int(ifid_ifval[0])
                    # ifval = float(ifid_ifval[1])
                    ofile.write(str(numpy.dot(U[ufid, :], V[ifid - self.numUsers, :])) + '\n')
            if self.nTestExamples % 2000000 == 0:
                sys.stdout.write('.')
        print('\n#nTest(pos,neg,total) = {},{},{}'.format(self.nTestPosExamples, self.nTestNegExamples, self.nTestExamples))


def test_cmf():
    start = time.time()
    metaFile = 'data/feat_ids_map_bookmovie.libfm'
    trainDataFile = 'data/book_u3i10_train_bin.libfm'  # same with libFM. [binary, log-scaled, original]
    testDataFile = 'data/book_u3i10_test_bin_wo.libfm'  # test without news
    #metaFile = 'data/feat_ids_map.libfm'
    #trainDataFile = 'data/user_apps_0_train_real_log.libfm'  # same with libFM. [binary, log-scaled, original]
    #testDataFile = 'data/user_apps_0_test_real_log_Recall.libfm'  # test without news and on Recall
    C = 10  # regu penalty [0.1] {0.5, 1, 5, 10}
    K = 20  # number of latent factors [50]; {20,30} in original paper
    alpha = 0.8  # [0.9]
    alphas = [alpha, 1 - alpha]
    T = 100  # number of iterations [100], {20,40,60,80}
    step = 0.3  # update step size [0.6], {0.1, 0.2,0.3}

    parameters = 'C'+str(C) + 'K'+str(K) + 'alpha'+str(alpha) + 'T'+str(T) + 'step'+str(step)
    print(parameters)

    cmf = CMF(metaFile, trainDataFile, testDataFile, C, K, T, alphas, step)
    print('must load metadata before train/test data. Now load metadata...')
    cmf.loadMetaData()
    print('---loadMetaData {}s---'.format(time.time() - start))

    print("load training data...")
    cmf.loadTrainData()
    for i in range(len(cmf.Xs_trn)):
        mat = cmf.Xs_trn[i]
        sys.stdout.write("Xs_trn[" + str(i) + "].shape:")
        print(mat.shape)
    print("*")
    print('---loadTrainData {}s---'.format(time.time() - start))

    #print("load test data...")
    #cmf.loadTestData()
    #sys.stdout.write("test matrix shape: ")
    #print(cmf.user_item_test.shape)
    #print("*")

    cmf.learn()
    print('******')
    for i in range(len(cmf.Us)):
        sys.stdout.write('the shape of factor/parameter matrices Us[' + str(i) + ']: ')
        print(cmf.Us[i].shape)
    print('********')
    print('---learn {} mins---'.format((time.time() - start) / 60))

    print('predicting & saving...')
    pred_file = 'data/book_u3i10_cmf_predict_' + parameters + '_bin_wo.libfm'
    #pred_file = 'data/user_apps_0_cmf_predict_' + 'C' + str(cmf.C) + 'K' + str(cmf.K) + 'alpha' + str(alpha) + '_real_log_.libfm'
    cmf.predict(pred_file)  # ONLY predict user x item
    print('wrote the predictions into the file: {}'.format(pred_file))
    print('---predict {} mins---'.format((time.time() - start) / 60))

    print("K: %d, C: %f" % (cmf.K, cmf.C))
    print("alphas: ", cmf.alphas)
    # print("rmse: %.4f , mae: %.4f\n" % (cfeval.rmse(Y_pred, X), cfeval.mae(Y_pred, X)))

    print('wrote factor matrices ...')
    with open('data/CMF_in_user_' + parameters + '.bin', 'w', encoding='utf-8') as ofileU:
        U = cmf.Us[0]
        for u in range(cmf.Ns[0]):
            ofileU.write(str(u) + ' ' + ' '.join([str(U[u][f]) for f in range(cmf.K)]) + '\n')
    with open('data/CMF_in_item_' + parameters + '.bin', 'w', encoding='utf-8') as ofileV:
        V = cmf.Us[1]
        for i in range(cmf.Ns[1]):
            ofileV.write(str(i) + ' ' + ' '.join([str(V[i][f]) for f in range(cmf.K)]) + '\n')
    with open('data/CMF_in_news_' + parameters + '.bin', 'w', encoding='utf-8') as ofileA:
        A = cmf.Us[2]
        for a in range(cmf.Ns[2]):
            ofileA.write(str(a) + ' ' + ' '.join([str(A[a][f]) for f in range(cmf.K)]) + '\n')

    print(parameters)

if __name__ == "__main__":
    test_cmf()
