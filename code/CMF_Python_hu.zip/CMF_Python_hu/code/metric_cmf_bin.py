from collections import defaultdict
import time
import math


start = time.time()

#########################################
########### test without article ###############
#########################################

instanceid_user_app = defaultdict(list)
user_AppLabels = defaultdict(lambda: defaultdict(int))
user_AppPos = defaultdict(set)
user_AppNeg = defaultdict(set)
test_pos = 0
test_neg = 0
test_total = 0
test_file_libfm = 'data/book_u3i10_test_bin_wo.libfm'
with open(test_file_libfm, 'r', encoding='utf-8') as ifile:
    for line in ifile:
        line = line[:50]  # read only: label ufid:1 ifid:1
        line = line.split(' ')
        ufid = int(line[1].split(':')[0])
        ifid = int(line[2].split(':')[0])
        label = int(line[0])
        if label > 0:
            user_AppPos[ufid].add(ifid)
            test_pos += 1
        else:
            user_AppNeg[ufid].add(ifid)
            test_neg += 1
        user_AppLabels[ufid][ifid] = label
        instanceid_user_app[test_total].append(ufid)
        instanceid_user_app[test_total].append(ifid)
        test_total += 1
print('test#(pos,neg;total) = {},{};{}'.format(test_pos, test_neg, test_total))
print('#user = {},{},{}'.format(len(user_AppPos), len(user_AppNeg), len(user_AppLabels)))

C = 10  # regu penalty [10] {0.5, 1, 5, 10}
K = 20  # number of latent factors [50]; {20,30} in original paper
alpha = 0.8  # [0.9]
T = 100  # number of iterations [100], {20,40,60,80}
step = 0.3  # update step size [0.6], {0.1,0.2,0.3,0.4,0.5}
parameters = 'C'+str(C) + 'K'+str(K) + 'alpha'+str(alpha) + 'T'+str(T) + 'step'+str(step)
print(parameters)

pred_user_item_valid_pos = defaultdict(list)
pred_user_item_valid_neg = defaultdict(list)
user_AppPreds_wo = defaultdict(lambda: defaultdict(int))
pred_total = 0
pred_file_libfm = 'data/book_u3i10_cmf_predict_' + parameters + '_bin_wo.libfm'
with open(pred_file_libfm, 'r', encoding='utf-8') as ifile:
    for line in ifile:
        line = line.strip()
        line = line.split(' ')
        pred = float(line[0])
        ufid = instanceid_user_app[pred_total][0]
        ifid = instanceid_user_app[pred_total][1]
        user_AppPreds_wo[ufid][ifid] = pred
        pred_total += 1
        label = user_AppLabels[ufid][ifid]
        if label > 0:
            pred_user_item_valid_pos[ufid] = [ifid, pred]  # 1 pos valid per uer
        else:
            pred_user_item_valid_neg[ufid].append([ifid, pred])  # 99 neg valid per user
print('#pred = {}'.format(pred_total))
print('--{} mins--'.format((time.time() - start) / 60))

topK = 10
hitrate10s = [0.] * len(pred_user_item_valid_pos)
ndcgs = [0.] * len(pred_user_item_valid_pos)
mrrs = [0.] * len(pred_user_item_valid_pos)
for u in pred_user_item_valid_pos:
    pos_item = pred_user_item_valid_pos[u][0]
    pos_pred = pred_user_item_valid_pos[u][1]
    item_preds = pred_user_item_valid_neg[u]

    item_preds.append(pred_user_item_valid_pos[u])
    item_preds = sorted(item_preds, key=lambda x: -x[1])  # from larger to smaller
    item_preds = item_preds[:topK]
    # compute MRR
    rank = 1
    for i,p in item_preds:
        if i == pos_item:
            mrrs[u] = 1 / rank
            break
        rank += 1
    # compute HitRate@10
    for i,p in item_preds:
        if i == pos_item:
            hitrate10s[u] = 1
            break
    # compute NDCG
    for position in range(len(item_preds)):
        i = item_preds[position][0]
        if i == pos_item:
            ndcgs[u] = math.log(2) / math.log(position+2)
            break

HitRate10 = 0
for hr in hitrate10s:
    HitRate10 += hr
HitRate10 /= len(pred_user_item_valid_pos)
print('HitRate10 = {}'.format(HitRate10))

NDCG = 0
for ndcg in ndcgs:
    NDCG += ndcg
NDCG /= len(pred_user_item_valid_pos)
print('NDCG = {}'.format(NDCG))

MRR = 0
for mrr in mrrs:
    MRR += mrr
MRR /= len(pred_user_item_valid_pos)
print('MRR = {}'.format(MRR))

print('--{} mins--'.format((time.time() - start) / 60))

'''
C10K20alpha0.8T100step0.3

'''