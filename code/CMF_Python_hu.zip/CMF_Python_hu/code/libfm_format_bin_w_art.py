from collections import defaultdict
import random
import time


start = time.time()
data_folder = 'data/'

###################################
## Generate metadata: users, items, context  ##
##################################

users_set = set()
apps_set = set()
nFeedback = 0

apps_user_train = defaultdict(set)
users_app_train = defaultdict(set)
nTrainfeedback = 0
train_file = data_folder + 'book_u3i10.train.rating'
with open(train_file, 'r', encoding='utf-8') as ifile:
    for line in ifile:
        line = line.strip()
        if not line:
            print('empty line')
            continue
        line = line.split('\t')
        user = int(line[0])
        users_set.add(user)
        app = int(line[1])
        apps_set.add(app)
        apps_user_train[user].add(app)
        users_app_train[app].add(user)
        nFeedback += 1
        nTrainfeedback += 1
print('#train(user,app,feed) = ({},{},{})'.format(len(apps_user_train), len(users_app_train), nTrainfeedback))
#train(user,app,feed) = (23111,14348,1118172)

apps_user_test = defaultdict(set)
users_app_test = defaultdict(set)
nTestfeedback = 0
test_file = data_folder + 'book_u3i10.valid.rating'
with open(test_file, 'r', encoding='utf-8') as ifile:
    for line in ifile:
        line = line.strip()
        if not line:
            print('empty line')
            continue
        line = line.split('\t')
        user = int(line[0])
        users_set.add(user)
        nFeedback += 1
        nTestfeedback += 1
        app = int(line[1])
        apps_set.add(app)
        apps_user_test[user].add(app)
        users_app_test[app].add(user)
print('#test(user,app,feed) = ({},{},{})'.format(len(apps_user_test), len(users_app_test), nTestfeedback))
#test(user,app,feed) = (23111,4871,23111)

print('#total(user,app,feed) = ({},{},{})'.format(len(users_set), len(apps_set), nFeedback))
#total(user,app,feed) = (23111,14348,1141283)

articles_set = set()
user_articles = defaultdict(set)
nReads = 0
dwellFile = data_folder + 'movie_u3i10.train.rating'
with open(dwellFile, 'r', encoding='utf-8') as ifile:
    for line in ifile:
        line = line.split('\t')
        user = int(line[0])
        if user not in users_set:
            continue
        article = int(line[1])
        articles_set.add(article)
        user_articles[user].add(article)
        nReads += 1
print('#(user,art,nReads) = ({},{},{})'.format(len(user_articles), len(articles_set), nReads))
#(user,art,nReads) = (23111,29918,570924)

feat_ids = defaultdict(int)
id_feats = defaultdict(str)
M = len(users_set)
N = len(apps_set)
L = len(articles_set)
n = M + N + L
feat_idx = 0
feat_map_file = data_folder + 'feat_ids_map_' + 'bookmovie' + '.libfm'
with open(feat_map_file, 'w', encoding='utf-8') as ofile:
    for u in users_set:
        ustr = 'u' + str(u)
        feat_ids[ustr] = feat_idx
        id_feats[feat_idx] = ustr
        ofile.write(ustr + ':' + str(feat_idx) + '\n')
        feat_idx += 1
    print(feat_idx)  # 23111
    for i in apps_set:
        istr = 'i' + str(i)
        feat_ids[istr] = feat_idx
        id_feats[feat_idx] = istr
        ofile.write(istr + ':' + str(feat_idx) + '\n')
        feat_idx += 1
    print(feat_idx)  # 37459
    for a in articles_set:
        astr = 'a' + str(a)
        feat_ids[astr] = feat_idx
        id_feats[feat_idx] = astr
        ofile.write(astr + ':' + str(feat_idx) + '\n')
        feat_idx += 1
print('#feats = {}. {:.2f}s'.format(feat_idx, (time.time() - start)))  # 67377

###################################
## Train w/ negative sampling  ##
##################################

trainapps_list = [app for app in users_app_train]
negativeRatio = 1  # the ratio of negative vs positive samples given each user
nTrainNegativefeedback = 0
train_file_libfm = data_folder + 'book_u3i10_train_bin.libfm'
with open(train_file, 'r', encoding='utf-8') as ifile:
    with open(train_file_libfm, 'w', encoding='utf-8') as ofile:
        nRead = 0
        for line in ifile:
            line = line.strip()
            if not line:
                print('empty line')
                continue
            line = line.split('\t')
            user = int(line[0])
            ustr = 'u' + str(user)
            ufid = feat_ids[ustr]
            # 1) positive samples
            size = int(line[1])
            item = int(line[1])
            istr = 'i' + str(item)
            ifid = feat_ids[istr]
            afid_list = []
            for a in user_articles[user]:
                astr = 'a' + str(a)
                afid = feat_ids[astr]
                afid_list.append(afid)
            sorted_afid_list = sorted(afid_list)
            head = '1 ' + str(ufid) + ':' + '1'
            tail = ' '.join([str(afid) + ':' + '1' for afid in sorted_afid_list])
            ofile.write(head + ' ' + str(ifid) + ':' + '1' + ' ' + tail + '\n')
            # 2) negative samples
            num_negative_samples = negativeRatio
            if len(trainapps_list) == len(apps_user_train[user]):
                continue
            while True:
                ind = int(len(trainapps_list) * random.random())
                neg_app = trainapps_list[ind]
                # if neg_app in model.apps_user_train[user]:
                if neg_app in apps_user_train[user] or neg_app in apps_user_test[user]:
                    continue
                ofile.write('0 ' + str(ufid) + ':' + '1' + ' ' + str(feat_ids['i'+str(neg_app)]) + ':' + '1' + '\n')
                nTrainNegativefeedback += 1
                num_negative_samples -= 1
                if num_negative_samples < 1:
                    break
            nRead += 1
            if nRead % 50000 == 0:
                print(nRead)
print('nTrainNegativefeedback={}. {:.2f}s'.format(nTrainNegativefeedback, (time.time() - start)))


#############################
##  Test for HitRatio, NDCG, MRR  ##
############################

nTestNegativefeedback = 0
negvalid_file_libfm = data_folder + 'book_u3i10.neg.valid.rating'
test_file_libfm_w = data_folder + 'book_u3i10_test_bin_w.libfm'
test_file_libfm_wo = data_folder + 'book_u3i10_test_bin_wo.libfm'
with open(negvalid_file_libfm, 'r', encoding='utf-8') as ifile:
    with open(test_file_libfm_w, 'w', encoding='utf-8') as ofile_w:
        with open(test_file_libfm_wo, 'w', encoding='utf-8') as ofile_wo:
            for line in ifile:
                line = line.strip()
                if not line:
                    print('empty line')
                    continue
                line = line.split('\t')
                user_positem = line[0].split(',')
                user = int(user_positem[0].split('(')[1])
                ustr = 'u' + str(user)
                ufid = feat_ids[ustr]
                # 1) positive samples
                pos_item = int(user_positem[1].split(')')[0])
                istr = 'i' + str(pos_item)
                ifid = feat_ids[istr]
                head = '1 ' + str(ufid) + ':' + '1'
                ofile_wo.write(head + ' ' + str(ifid) + ':' + '1' + '\n')
                ofile_w.write(head + ' ' + str(ifid) + ':' + '1' + ' ' + tail + '\n')
                # 2) negative samples
                neg_ifid_list = []
                for neg in line[1:]:
                    neg = int(neg)
                    istr = 'i' + str(neg)
                    ifid = feat_ids[istr]
                    neg_ifid_list.append(ifid)
                sorted_neg_ifid_list = sorted(neg_ifid_list)
                neg_head = '0 ' + str(ufid) + ':' + '1'
                for neg_ifid in sorted_neg_ifid_list:
                    ofile_wo.write(neg_head + ' ' + str(neg_ifid) + ':' + '1' + '\n')
                    ofile_w.write(neg_head + ' ' + str(neg_ifid) + ':' + '1' + ' ' + tail + '\n')
                    nTestNegativefeedback += 1
print('#nTestNegativefeedback={}. {:.2f}'.format(nTestNegativefeedback, (time.time() - start)))

'''
cat _test_bin_w.libfm _test_bin_wo.libfm > _test_bin.libfm
./libFM -task c -train user_apps_0_train_bin.libfm -test user_apps_0_test_bin.libfm -dim ’1,1,10’ -out user_apps_0_bin_predict.libfm
'''
