#pragma once
#include "language.hpp"
#include "common.hpp"
#include <random> 
using namespace std;

class topicCorpus{
public:
  topicCorpus(corpus* corp, // The corpus
              int K, // The number of latent factors
              double latentUV, // Parameter regularizer used by the "standard" recommender system
			  double latentBias, //
			  double lattenH,
			  double latentAlpha, // social regularizer used by LOCABAL
              double lambda) : // Word regularizer used by HFT
			  corp(corp), K(K), latentUV(latentUV),latentBias(latentBias),latentH(latentH),latentAlpha(latentAlpha),lambda(lambda)
  {

	this->countPredTimes = -1;
	this->overallAverage = 0;
	this->eNorms = 0;
	this->eRatings = 0;
	this->eReviews = 0;
	this->learingRate = 0.0005; //0.001 (50/100000=0.0005):0.0005 for #train != 99%, 0.00001 for =999%

   // this->epoches = 5; //5 grad descent per 1 topic update
	this->momentum = 0.8; //0.8
    this->numBatches = 9; //9*70000=630000
    this->sizeTrain = 630000; //630000
	this->sizeBatch = 20000; // this->sizeTrain / this->numBatches; //70000

//    srand(0);

	//1. (train,valid,test) = 8:1:1
    nUsers = corp->nUsers;
    nBeers = corp->nBeers;
    nWords = corp->nWords;

	this->NW = (K + 1) * (nUsers + nBeers); //PMF: UV, bias; Now remove overallAverage
	if( this->lambda > 0) //HFT
		NW += 1 + K * nWords; //kappa + topic-word distribution
	if (this->latentAlpha > 0) //LOCABAL
		NW += K * K; //social relation matrix H
	printf("#parameters = %d\n", NW);

	for (int u = 0; u < nUsers; u++)
		trainUsers.push_back(u);
	for (int b = 0; b < nBeers; b++)
		trainBeers.push_back(b);

	beta_user.resize(nUsers);
	beta_user_inc.resize(nUsers);
	gamma_user.resize(nUsers,vector<double>(K));
	gamma_user_inc.resize(nUsers,vector<double>(K));
	for (int u = 0; u < nUsers; u++){
	  for (int k = 0; k < K; k++){
	    gamma_user[u][k] =  0; //gamma_user[u][k] = rand() * 0.1 / RAND_MAX
		gamma_user_inc[u][k] =  0;
	  };
	  beta_user[u] = 0;
	  beta_user_inc[u] = 0;
	}
	beta_beer.resize(nBeers);
	beta_beer_inc.resize(nBeers);
	gamma_beer.resize(nBeers,vector<double>(K));
	gamma_beer_inc.resize(nBeers,vector<double>(K));
    for (int b = 0; b < nBeers; b++){
	  for (int k = 0; k < K; k++){
		gamma_beer[b][k] = 0;
		gamma_beer_inc[b][k] = 0;
	  }
	  beta_beer[b] = 0;
	  beta_beer_inc[b] = 0;
	}

	implicit_rating.resize(nBeers, vector<double>(K));
	implicit_rating_inc.resize(nBeers, vector<double>(K));
	for (int b = 0; b < nBeers; b++){
		for (int k = 0; k < K; k++){
			implicit_rating[b][k] = 0;
			implicit_rating_inc[b][k] = 0;
		}
	}

    votesPerUser = new std::vector<vote*>[nUsers];
    votesPerBeer = new std::vector<vote*>[nBeers];
    trainVotesPerUser = new std::vector<vote*>[nUsers];
    trainVotesPerBeer = new std::vector<vote*>[nBeers];
    for (std::vector<vote*>::iterator it = corp->V->begin(); it != corp->V->end(); it++){
      vote* vi = *it;
      votesPerUser[vi->user].push_back(vi);
    }
    for (int user = 0; user < nUsers; user++)
    for (std::vector<vote*>::iterator it = votesPerUser[user].begin(); it != votesPerUser[user].end(); it++){
      vote* vi = *it;
      votesPerBeer[vi->item].push_back(vi);
    }

	double trainFraction = 0.8;
	double testFraction = 1 - trainFraction;	//(train,valid,test) = 8:1:1
	int trainSize = 0;
	int testSize = 0;
    for (std::vector<vote*>::iterator it = corp->V->begin(); it != corp->V->end(); it++){
		double r = rand() * 1.0 / RAND_MAX;
		//  if (countTrainSize  < this->sizeTrain){
		if (r <= trainFraction){
			trainVotes.push_back(*it);
			trainVotesPerUser[(*it)->user].push_back(*it);
			trainVotesPerBeer[(*it)->item].push_back(*it);
			if (nTrainingPerUser.find((*it)->user) == nTrainingPerUser.end())
				nTrainingPerUser[(*it)->user] = 0;
			if (nTrainingPerBeer.find((*it)->item) == nTrainingPerBeer.end())
				nTrainingPerBeer[(*it)->item] = 0;
			nTrainingPerUser[(*it)->user]++;
			nTrainingPerBeer[(*it)->item]++;
			trainSize++;
		}
		else if (r <= trainFraction + testFraction)
			testVotes.insert(*it);
		else
			validVotes.insert(*it);
    }
	printf("#train=%d,#valid=%d,#test=%d\n",trainVotes.size(),validVotes.size(),testVotes.size());

	//2. remove examples (users or items) in test which don't occur in train set
    std::vector<vote*> removeTest;
    for (std::set<vote*>::iterator it = testVotes.begin(); it != testVotes.end(); it ++)
      if (nTrainingPerUser.find((*it)->user) == nTrainingPerUser.end()) removeTest.push_back(*it);
      else if (nTrainingPerBeer.find((*it)->item) == nTrainingPerBeer.end()) removeTest.push_back(*it);
    for (std::vector<vote*>::iterator it = removeTest.begin(); it != removeTest.end(); it ++)
   	  testVotes.erase(*it);
	printf("#examples = %d(users or items) in test not occur in train set\n",removeTest.size() );

	std::vector<vote*> removeValid;
    for (std::set<vote*>::iterator it = validVotes.begin(); it != validVotes.end(); it ++)
      if (nTrainingPerUser.find((*it)->user) == nTrainingPerUser.end()) removeValid.push_back(*it);
      else if (nTrainingPerBeer.find((*it)->item) == nTrainingPerBeer.end()) removeValid.push_back(*it);
    for (std::vector<vote*>::iterator it = removeValid.begin(); it != removeValid.end(); it ++)
   	  validVotes.erase(*it);
	printf("#examples = %d (users or items) in valid not occur in train set\n",removeValid.size() );

	//3. global ratings average, users ratings bias, items ratings bias
	for (std::vector<vote*>::iterator vi = trainVotes.begin(); vi != trainVotes.end(); vi++)
      overallAverage += (*vi)->value;
    overallAverage /= trainVotes.size(); //4.1398
	cout << "Overall average = " << overallAverage << endl;
	
    double train, valid, test, testSte;
    validTestError(train, valid, test, testSte);
    printf("Error(RMSE) Offset only (tr/va/te) = %f/%f/%f+-%f\n",train, valid, test, testSte);
	
	for (std::vector<vote*>::iterator vi = trainVotes.begin(); vi != trainVotes.end(); vi++){
      vote* v = *vi;
      beta_user[v->user] += v->value - overallAverage;
      beta_beer[v->item] += v->value - overallAverage;
    }
    for (int u = 0; u < nUsers; u++) // the user in total maybe not all occur in trainVotes
	  if(beta_user[u] != 0)
		//beta_user[u] /= trainVotesPerUser[u].size();
		beta_user[u] /= votesPerUser[u].size();  //trainVotesPerUser[u].size();//why not trainVotesPerUser[u].size()
    for (int b = 0; b < nBeers; b++)
	  if(beta_beer[b] != 0)
		//beta_beer[b] /= trainVotesPerBeer[b].size();
		beta_beer[b] /=  votesPerBeer[b].size(); //trainVotesPerBeer[b].size(); //
    validTestError(train, valid, test, testSte);
    printf("Error(RMSE) Offset+Bias (tr/va/te) = %f/%f/%f+-%f\n", train, valid, test, testSte);

	this->overallAverage *= 1.0; //momentum: overall = 3.95, too optimistic

	if (this->lambda > 0)
	{
		cout << "init wordTopicCounts[w][k]" << endl;
		wordTopicCounts = new int*[nWords];
		for (int w = 0; w < nWords; w++){
			wordTopicCounts[w] = new int[K];
			for (int k = 0; k < K; k++)
				wordTopicCounts[w][k] = 0;
		}
		topicCounts = new long long[K];
		for (int k = 0; k < K; k++)
			topicCounts[k] = 0;
		beerTopicCounts = new int*[nBeers];
		beerWords = new int[nBeers];
		for (int b = 0; b < nBeers; b++){
			beerTopicCounts[b] = new int[K];
			for (int k = 0; k < K; k++)
			  beerTopicCounts[b][k] = 0;
			beerWords[b] = 0;
		}

		for (std::vector<vote*>::iterator vi = trainVotes.begin(); vi != trainVotes.end(); vi++){
			vote* v = *vi;
			wordTopics[v] = new int[v->words.size()];
			beerWords[(*vi)->item] += v->words.size(); // a 'doc' = a beer text reviewed by all users
			for (int wp = 0; wp < (int)v->words.size(); wp++) // words.size() can be zero
			{
				int wi = v->words[wp];
				int t = rand() % K;
				wordTopics[v][wp] = t; // topic assign by random: z_{d,n} = k
				beerTopicCounts[(*vi)->item][t]++; // theta_{d,k}
				wordTopicCounts[wi][t]++;
				topicCounts[t]++;
			}
		}
		totalWords = 0;
		backgroundWords.resize(nWords);
		for (int w = 0; w < nWords; w++)
			backgroundWords[w] = 0;
		for (std::vector<vote*>::iterator vi = trainVotes.begin(); vi != trainVotes.end(); vi++)
		  for (std::vector<int>::iterator it = (*vi)->words.begin(); it != (*vi)->words.end(); it++){
			totalWords++;
			backgroundWords[*it]++;
		  }
		for (int w = 0; w < nWords; w++)
			backgroundWords[w] /= totalWords;
		printf("totalWords(train) = %d\n", totalWords);
	}

	//4. 1)Phi_{w,k} 2)Theta_{d,k} 3)Z_{d_{i,j},n}
	if(this->lambda > 0)
	{
		topicWords.resize(nWords,vector<double>(K));
		topicWords_inc.resize(nWords,vector<double>(K));
		for (int w = 0; w < nWords; w++)
        for (int k = 0; k < K; k++){
          topicWords[w][k] = 0;
		  topicWords_inc[w][k] = 0;
		}
	}
	cout << "init U,V" << endl;
	//PMF random init (VS. zero init)
	std::default_random_engine gen;
	std::normal_distribution<double> gauss(0,0.1); //Normal(mean,std)
	double init = 0;
    for (int u = 0; u < nUsers; u++)
	  for (int k = 0; k < K; k++){
		gamma_user[u][k] = 0.1 * gauss(gen); //gamma_user[u][k] = rand() * 0.1 / RAND_MAX
	  };
    for (int b = 0; b < nBeers; b++)
	  for (int k = 0; k < K; k++){
		gamma_beer[b][k] = 0.1 * gauss(gen);
		implicit_rating[b][k] = 0.1 * gauss(gen);
	  }
	cout << "init kappa" << endl;
	//5. HFT or PMF
	if(this->lambda > 0)
	{
		kappa = 1.0;
		kappa_inc = 0;
	}
	cout << "init social H" << endl;
	//5. LOCABAL or PMF
	if (this->latentAlpha > 0)
	{
		social_h.resize(K, vector<double>(K));
		social_h_inc.resize(K, vector<double>(K));
		for (int i = 0; i < K; i++)
		  for (int j = 0; j < K; j++){
			social_h[i][j] = 0.1 * gauss(gen);;
			social_h_inc[i][j] = 0;
		  }
	}

	if (lambda > 0) // HFT: First updateTopics, then L-BFGS;...
	{
		normalizeWordWeights();
		updateTopics(true);
	}

	// saveVotesPerUserItem();
  }

  void saveVotesPerUserItem(void) {
	printf("Saving userId-userName = %d :\n",this->corp->rUserIds.size() );
    fflush(stdout);
	FILE *fmap = fopen_("userId-userName.txt","w");
	for(int u=0; u < nUsers; u++){
		fprintf(fmap,"%d %s \n", u,this->corp->rUserIds[u].c_str() ); 
	}
	fclose(fmap);

	printf("Saving userName-userId = %d :\n",this->corp->userIds.size() );
    fflush(stdout);
	fmap = fopen_("userName-userId.txt","w");
	for(std::map<std::string, int>::iterator it = this->corp->userIds.begin();it !=  this->corp->userIds.end(); it++){ 
		fprintf(fmap,"%s %d \n", it->first.c_str(), it->second ); 
	}
	fclose(fmap);
	
    printf("Saving votesPerUser = %d :\n",this->corp->rUserIds.size() );
    fflush(stdout);
	FILE *f = fopen_("votesPerUser.txt","w");
	for(int u=0; u < nUsers; u++){
		//cout << u << " " << this->corp->rUserIds[u].c_str() << endl;
		fprintf(f,"%s: ",this->corp->rUserIds[u].c_str() ); 
		for(vector<vote*>::iterator it = votesPerUser[u].begin(); it != votesPerUser[u].end(); it++){
		   //assert (this->corp->rUserIds[u] == this->corp->rUserIds[(*it)->user]);
		  fprintf(f,"%s %s %d %d ",this->corp->rUserIds[(*it)->user].c_str(),this->corp->rBeerIds[(*it)->item].c_str(),(int)((*it)->value),(*it)->words.size());
		}
		fprintf(f,"\n");
	}
	fclose(f);

	printf("Saving votesPerItem = %d:\n",this->corp->rBeerIds.size() );
	fflush(stdout);
	f = fopen_("votesPerItem.txt","w");
	for(int b=0; b < nBeers; b++){
		fprintf(f,"%s: ",this->corp->rBeerIds[b].c_str()); 
		for(vector<vote*>::iterator it = votesPerBeer[b].begin(); it != votesPerBeer[b].end(); it++){
		   //assert (this->corp->rBeerIds[b] == this->corp->rBeerIds[(*it)->item]);
		  fprintf(f,"%s %s %d %d ",this->corp->rUserIds[(*it)->user].c_str(),this->corp->rBeerIds[(*it)->item].c_str(),(int)((*it)->value),(*it)->words.size());
		}
		fprintf(f,"\n");
	}
	fclose(f);

	printf("\n");
  }

  ~topicCorpus()
  {
    delete[] votesPerBeer;
    delete[] votesPerUser;
    delete[] trainVotesPerBeer;
    delete[] trainVotesPerUser;
	if(this->lambda > 0)
	{
		for (int w = 0; w < nWords; w ++)
		  delete[] wordTopicCounts[w];
		delete[] wordTopicCounts;
		for (int b = 0; b < nBeers; b ++)
		  delete[] beerTopicCounts[b];
		delete[] beerTopicCounts;
		delete[] beerWords;
		delete[] topicCounts;
		for (std::vector<vote*>::iterator vi = trainVotes.begin(); vi != trainVotes.end(); vi++)
		  delete[] wordTopics[*vi];
	}
  }

/// Free parameters
  void topicCorpus::clearG(double** alpha,
							double** kappa,
							double** beta_user,
							double** beta_beer,
							double*** gamma_user,
							double*** gamma_beer,
							double*** topicWords)
  {
	delete[] (*gamma_user);
	delete[] (*gamma_beer);
	delete[] (*topicWords);
  }

 // double RMSEtrain(void);
//  double RMSEvalid(void);
 // double RMSEtest(void);

  void wordZ(double* res);
  void topicZ(int beer, double& res);
  void updateTopics(bool sample);
  void topWords();
  double prediction(vote* vi, double* parts = nullptr);

  double predSim(int u1, int u2);
  vector<double> predHHu(int u);
  vector<vector<double>> predHuu(int u1, int u2);
  // double predM(vote* vi);

 // double predM(vote* vi);
  void train(int emIterations, int epoches = 10);
  void dl(double* grad);
  double lsq(void);

  void validTestError(double& train, double& valid, double& test, double& testSte);
  
  void normalizeWordWeights(void);
  void save(char* modelPath, char* predictionPath);

  corpus* corp;
  std::map<int,int> nTrainingPerUser; // Number of training items for each user
  std::map<int,int> nTrainingPerBeer; // and item
  int nUsers; // Number of users
  int nBeers; // Number of items
  int nWords; // Number of words
  // Votes from the training, validation, and test sets
  std::vector<vote*> trainVotes;
  std::set<vote*> validVotes;
  std::set<vote*> testVotes;
  std::map<vote*, double> bestValidPredictions;
  std::vector<vote*>* votesPerBeer; // Vector of votes for each item
  std::vector<vote*>* votesPerUser; // Vector of votes for each user
  std::vector<vote*>* trainVotesPerBeer; // Same as above, but only votes from the training set
  std::vector<vote*>* trainVotesPerUser;
  vector<int> trainUsers;
  vector<int> trainBeers;

  double overallAverage; // Offset parameter. Now fixed it: 3.95
  // Model parameters and their derivatives
  double kappa; // "peakiness" parameter.Used for transforming/aligning gamma_beer and theta
  double kappa_inc; // "peakiness" parameter.Used for transforming/aligning gamma_beer and theta

  vector<double> beta_user; // User offset parameters
  vector<double> beta_beer; // Item offset parameters
  vector<double> beta_user_inc; // User offset parameters
  vector<double> beta_beer_inc; // Item offset parameters
  vector<vector<double>> gamma_user; // User latent factors
  vector<vector<double>> gamma_beer; // Item latent factors
  vector<vector<double>> implicit_rating; // Implicit factors from ratings (SVD++)
  vector<vector<double>> gamma_user_inc; // User latent factors
  vector<vector<double>> gamma_beer_inc; // Item latent factors
  vector<vector<double>> implicit_rating_inc; // Implicit factors from ratings (SVD++)

  vector<vector<double>> topicWords; //Phi_{w,k} Weights each word in each topic
  vector<double> backgroundWords; // "background" weight, so that each word has average weight zero across all topics
  vector<vector<double>> topicWords_inc;

  vector<vector<double>> social_h; // User latent correlated: K x K
  vector<vector<double>> social_h_inc; // User latent correlated: K x K

  int NW; // 1 + 1 + (K + 1) * (nUsers + nBeers) + K * nWords; Now remove alpha (overall average)
  
  // Hyper-parameters
  double latentUV;
  double latentBias;
  double latentH;
  double lambda; //review
  double latentAlpha; //social
  int K;

  // Latent variables
  std::map<vote*, int*> wordTopics; // z_{d_{i,j},n}

  // Counters
  int** beerTopicCounts; //Theta_{d,k} How many times does each topic occur for each product?
  int* beerWords; // Number of words in each "document"
  long long* topicCounts; // How many times does each topic occur?
  int** wordTopicCounts; //Psi_{w,k} How many times does this topic occur for this word?
  long long totalWords; // How many words are there?
  
  //Energy of each kind of information (including norm-penalty)
  double eTotal;
  double eRatings;
  double eRelations;
  double eReviews;
  double eNorms;
 // double eImplicitRatings; //included in the eRatings

  //Gradient descent
  double learingRate; //0.001 (50/70000=0.0007)
  double momentum; //0.8
  double epoches;
  int numBatches; //9*70000=630000
  int sizeBatch; //70000
  int sizeTrain; //630000

  vector<vector<double>> predList;
  int countPredTimes;

  typedef pair<int, int> Key;
  typedef map<Key, double> MapPair;
};
