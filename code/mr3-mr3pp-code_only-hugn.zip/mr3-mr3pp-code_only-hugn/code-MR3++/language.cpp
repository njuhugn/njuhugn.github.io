#include "language.hpp"
#include "common.hpp"
#include "limits"
#include <string>
#include "time.h"
#include <cstdlib>
#include <cstdio>
#include <algorithm> // random_shuffle
using namespace std;
inline double square(double x){return x * x; }
inline double dsquare(double x){return 2 * x; }
double clock_(){
  time_t timer;
  time(&timer);
  return (double)timer;
}
double topicCorpus::predSim(int u1, int u2){
	vector<double> temp(K, 0);
	for (int k = 0; k < K; k++)
		for (int i = 0; i < K; i++)
			temp[k] += gamma_user[u1][i] * social_h[i][k];
	double sim = 0;
	for (int k = 0; k < K; k++)
		sim += temp[k] * gamma_user[u2][k];
	return sim;
}
vector<double> topicCorpus::predHHu(int u){
	vector<double> HHu(K, 0);
	for (int k = 0; k < K; k++)
		for (int i = 0; i < K; i++)
			HHu[k] = (social_h[k][i] + social_h[i][k]) * gamma_user[u][i];
	return HHu;
}
vector<vector<double>> topicCorpus::predHuu(int u1, int u2){
	vector<vector<double>> Huu(K, vector<double>(K));
	for (int k = 0; k < K; k++)
		std::fill(Huu[k].begin(), Huu[k].end(), 0);
	for (int i = 0; i < K; i++)
		for (int j = 0; j < K; j++)
			Huu[i][j] = gamma_user[u1][i] * gamma_user[u2][j];
	return Huu;
}
/// Predict a particular rating given the current parameter values
double topicCorpus::prediction(vote* vi, double* parts){
 // cout << "func:prediction" << endl;
  int user = vi->user;
  int beer = vi->item;
  double res = overallAverage + beta_user[user] + beta_beer[beer];
  double UV = 0;
  for (int k = 0; k < K; k++)
	UV += gamma_user[user][k] * gamma_beer[beer][k];

  if(parts != nullptr){
	  parts[0] = overallAverage;
	  parts[1] = beta_user[user];
	  parts[2] = beta_beer[beer];
	  parts[3] = UV;
  }
  res += UV;

  double YV = 0;
  for (vector<vote*>::iterator it = trainVotesPerUser[user].begin(); it != trainVotesPerUser[user].end(); it++){
	  vote* vi = *it;
	  int j = vi->item;
	  for (int k = 0; k < K; k++)
		  YV += implicit_rating[j][k] * gamma_beer[beer][k];
  }
  if (trainVotesPerUser[user].size() != 0)
	  YV /= sqrt(trainVotesPerUser[user].size());

  res += YV;
  if(res > 5) res = 5;
  else if( res < 1) res = 1;
 // cout << "func:prediction-END" << endl;
  return res;
}
//double topicCorpus::predM(vote* vi){
//  int user = vi->user;
//  int beer = vi->item;
//  double res = beta_user[user] + beta_beer[beer];
//  double UV = 0;
//  for (int k = 0; k < K; k++)
//	UV += gamma_user[user][k] * gamma_beer[beer][k];
//  res += UV;
//  if(res > 5) res = 5;
//  else if( res < 1) res = 1;
//  return res;
//}
/// Compute normalization constant for a particular item
void topicCorpus::topicZ(int beer, double& res){
  res = 0;
  for (int k = 0; k < K; k++)
    res += exp(kappa * gamma_beer[beer][k]);
}
/// Compute normalization constants for all K topics
void topicCorpus::wordZ(double* res){
  for (int k = 0; k < K; k++){
    res[k] = 0;
    for (int w = 0; w < nWords; w++)
      res[k] += exp(backgroundWords[w] + topicWords[w][k]);
  }
}
/// Update topic assignments for each word. If sample==true, this is done by sampling, 
/// otherwise it's done by maximum likelihood (which doesn't work very well)
void topicCorpus::updateTopics(bool sample){
  double updateStart = clock_();
  printf("updateTopics...\n");
  fflush(stdout);
  for (int x = 0; x < (int) trainVotes.size(); x++) {
	if (x > 0 && x % 100000 == 0){
      printf("T"); fflush(stdout);
    }
    vote* vi = trainVotes[x];
    int beer = vi->item;
    int* topics = wordTopics[vi];//z_{d_{i,j},n}
    for (int wp = 0; wp < (int) vi->words.size(); wp++){ 
      int wi = vi->words[wp]; // The word
      double* topicScores = new double[K];
      double topicTotal = 0;
      for (int k = 0; k < K; k++){
        topicScores[k] = exp((kappa * gamma_beer[beer][k]) + (backgroundWords[wi] + topicWords[wi][k]));//Eq.8 Eq.9: theta * phi
        topicTotal += topicScores[k];
      }
      for (int k = 0; k < K; k++)
        topicScores[k] /= topicTotal;
      int newTopic = 0;
      if (sample){
        double x = rand() * 1.0 / (1.0 + RAND_MAX); // x is in [0,1]
        while (true){
          x -= topicScores[newTopic]; // Eq.(8)(3): the sampled pr. of topic k is proportion to its topic score
          if (x < 0) break;
          newTopic++;
        }
      }
      delete[] topicScores;
      if (newTopic != topics[wp]){ // Update topic counts if the topic for this word position changed
        int t = topics[wp];
        wordTopicCounts[wi][t]--; //original topic --
        wordTopicCounts[wi][newTopic]++; //new sampled topic ++
        topicCounts[t]--;
        topicCounts[newTopic]++;
        beerTopicCounts[beer][t]--;
        beerTopicCounts[beer][newTopic]++;
        topics[wp] = newTopic; // modify topics = modify wordTopics
      }
    }
  }
  //cout << "func: updateTopics-END" << endl;
  printf("\n");
}

/// Compute the energy according to the least squares criterion
double topicCorpus::lsq(){
  //cout << "func: lsq" << endl;

  double lsqStart = clock_();
  double res = 0; this->eRatings = 0; this->eRelations = 0; this->eReviews = 0; this->eNorms = 0;
  //1. ratings
  for (int x = 0; x < (int) trainVotes.size(); x++){
    vote* vi = trainVotes[x];
	double inc = vi->gWeight * square(prediction(vi) - vi->value);
	res += inc;
	this->eRatings += inc;
  }
  //3. norms. if(latentReg > 0)
  if(latentUV > 0){
	  for (int u = 0; u < nUsers; u++)
		for (int k = 0; k < K; k++){
		  double inc = latentUV * square(gamma_user[u][k]);
		  res += inc;
		  this->eNorms += inc;
		}
	  for (int b = 0; b < nBeers; b++)
		for (int k = 0; k < K; k++){
		  double inc = latentUV * square(gamma_beer[b][k]);
		  res += inc;
		  this->eNorms += inc;
		}
  }
  if(latentBias > 0){
	  for (int u = 0; u < nUsers; u++){
		  double inc = latentBias * beta_user[u];
		  res += inc;
		  this->eNorms += inc;
	  }
	  for (int b = 0; b < nBeers; b++){
		  double inc = latentBias * beta_beer[b];
		  res += inc;
		  this->eNorms += inc;
	  }
  }
  if (this->latentAlpha > 0 && latentH > 0)
  {
	  for (int i = 0; i < K; i++)
		  for (int j = 0; j < K; j++){
		  double inc = latentH * square(social_h[i][j]);
		  res += inc;
		  this->eNorms += inc;
		  }
  }
  //2. reviews. Eq.(3) (5), -logP: Theta * Phi
	if(this->lambda > 0)
	{
	  for (int b = 0; b < nBeers; b++){ //1) Theta: doc-topic
		double tZ;
		topicZ(b, tZ); //normal const i.e. denominator Eq.(4) in paper HFT (RecSys2013)
		double lZ = log(tZ);
		for (int k = 0; k < K; k++){
			double inc = -lambda * beerTopicCounts[b][k] * (kappa * gamma_beer[b][k] - lZ);
			res += inc;
			this->eReviews += inc;
		}
	  }
	  double* wZ = new double[K];
	  wordZ(wZ); // normal const i.e. denominator Eq.(9) in paper HFT (RecSys2013)
	  for (int k = 0; k < K; k++){ //2) Phi: topic-word
		double lZ = log(wZ[k]);
		for (int w = 0; w < nWords; w++){
			double inc = -lambda * wordTopicCounts[w][k] * (backgroundWords[w] + topicWords[w][k] - lZ);
			res += inc;
			this->eReviews += inc;
		}
	  }
	  delete[] wZ;
	}
	//2. relations. 
	if (this->latentAlpha > 0)
	{
		for (int u = 0; u < nUsers; u++){
			map<int, double> neighborStrength = this->corp->neighborSimPerUser[u];
			for (map<int, double>::iterator it = neighborStrength.begin(); it != neighborStrength.end(); it++){
				double strength = 1.0;

				Key key(u, it->first);
				auto itSim = this->corp->userStrengthMap.find(key);
				if (itSim != this->corp->userStrengthMap.end()) //eSMF
					strength *= itSim->second; // rating sim as a weight to social strength

				double inc = latentAlpha * strength* square(predSim(u, it->first) - it->second);
				res += inc;
				this->eRelations += inc;
			}
		}
	}
 // cout << "func: lsq-END" << endl;
  double lsqEnd = clock_();
  return res;
}
/// Compute the average and the variance
void averageVar(vector<double>& values, double& av, double& var){
  double sq = 0; av = 0; var = 0; //var = 0;
  for (vector<double>::iterator it = values.begin(); it != values.end(); it++){
    av += *it;
    sq += (*it) * (*it);
  }
  av /= values.size();
  sq /= values.size();
  var = sq - av * av; //DX = E(X^2) - (EX)^2
}
/*
double topicCorpus::RMSEtrain(void){
	double rmse = 0;
	for (vector<vote*>::iterator it = trainVotes.begin(); it != trainVotes.end(); it++)
		rmse += square(prediction(*it) - ((*it)->value - this->overallAverage) );
	for (int u = 0; u < nUsers; u++){
		for (int k = 0; k < K; k++){
			rmse += this->latentUV * gamma_user[u][k]*gamma_user[u][k];
		}
		rmse += this->latentBias * beta_user[u]*beta_user[u];
	}
	for (int b = 0; b < nBeers; b++){
	  for (int k = 0; k < K; k++){
		  rmse += this->latentUV * gamma_beer[b][k]*gamma_beer[b][k];
	  }
	  rmse += this->latentBias * beta_beer[b]*beta_beer[b];
	}
	rmse /= trainVotes.size();
	rmse = sqrt(rmse);  //RMSE
	return rmse;
}
double topicCorpus::RMSEvalid(void){
	double rmse = 0;
	for (set<vote*>::iterator it = validVotes.begin(); it != validVotes.end(); it++)
		rmse += square(prediction(*it) + this->overallAverage - (*it)->value);
	rmse /= validVotes.size();
	rmse = sqrt(rmse);  //RMSE
	return rmse;

}
double topicCorpus::RMSEtest(void){
	double rmse = 0;
	for (set<vote*>::iterator it = testVotes.begin(); it != testVotes.end(); it++)
		rmse += square(prediction(*it) + this->overallAverage - (*it)->value);
	rmse /= testVotes.size();
	rmse = sqrt(rmse);  //RMSE
	return rmse;

}
*/
/// Compute the validation and test error RMSE/MSE (and testing standard error)
void topicCorpus::validTestError(double& train, double& valid, double& test, double& testSte){
 // cout << "func: validTestError" << endl;

  train = 0; valid = 0; test = 0;
  for (vector<vote*>::iterator it = trainVotes.begin(); it != trainVotes.end(); it++)
    train += square(prediction(*it) - (*it)->value);
 
  //cout << "func: validTestError-valid" << endl;
  for (set<vote*>::iterator it = validVotes.begin(); it != validVotes.end(); it++)
    valid += square(prediction(*it) - (*it)->value);

 // cout << "func: validTestError-test" << endl;
  for (set<vote*>::iterator it = testVotes.begin(); it != testVotes.end(); it++){
	double parts[] = {0,0,0,0};
    double err = square(prediction(*it,parts) - (*it)->value);
    test += err;
	//vector<double> pair;
	//pair.push_back((*it)->value);
	//pair.push_back(prediction(*it));
	//pair.push_back(parts[0]); //overall
	//pair.push_back(parts[1]); //user bias
	//pair.push_back(parts[2]); //beer bias
	//pair.push_back(parts[3]); //UV
	//predList.push_back(pair);
  }
  train /= trainVotes.size(); valid /= validVotes.size(); test /= testVotes.size();
  train = sqrt(train);   valid = sqrt(valid);  test = sqrt(test); //RMSE

 // string pred = "pred " + std::to_string(test) + " " + std::to_string(this->countPredTimes) + ".txt";
 // FILE* f = fopen(pred.c_str(),"w");
 // vector<double> pair;
 // for(vector<vector<double>>::iterator it = predList.begin(); it != predList.end(); it++){
	//  pair = *it;
	//  fprintf(f,"(%f %f) [%f %f] %f %f %f\n",pair[0],pair[1],pair[2]+pair[3]+pair[4],pair[5],pair[2],pair[3],pair[4]);
	//  //(test pred) mean+bias+bias UV mean uBias IBias
 // }
 // fclose(f);
 // predList.clear();

 // string UV = "pred UV " + std::to_string(test) + " " + std::to_string(this->countPredTimes) + ".txt";
 // f = fopen(UV.c_str(),"w");
 // for (int u = 0; u < nUsers; u++){
	//for (int k = 0; k < K; k++){
	//  fprintf(f,"%f ",gamma_user[u][k]);
	//}
	//fprintf(f,"\n");
 // }
 // fprintf(f,"\n****************************\n");
 // for (int b = 0; b < nBeers; b++){
	//for (int k = 0; k < K; k++){
	// fprintf(f,"%f ",gamma_beer[b][k]);
	//  this->eNorms += latentUV * square(gamma_beer[b][k]);
	//}
	//fprintf(f,"\n");
 // }
 // fclose(f);

  this->countPredTimes++;
 // cout << "func: validTestError-END" << endl;
}
/// Print out the top words for each topic
void topicCorpus::topWords(){
  printf("Top-10 words for each topic...\n");
  for (int k = 0; k < K; k++){
	printf("\tTopic = %d:\n", k);
    vector < pair<double, int> > bestWords;
    for (int w = 0; w < nWords; w++)
      bestWords.push_back(pair<double, int> (-topicWords[w][k], w));
    sort(bestWords.begin(), bestWords.end());
    for (int w = 0; w < 10; w++)
      printf("%s(%f) ", corp->idWord[bestWords[w].second].c_str(), -bestWords[w].first);
    printf("\n");
  }
}
/// Subtract averages from word weights so that each word has average weight zero across all topics
/// (the remaining weight is stored in "backgroundWords")
void topicCorpus::normalizeWordWeights(void){
  for (int w = 0; w < nWords; w++){
    double av = 0;
    for (int k = 0; k < K; k++)
      av += topicWords[w][k];
    av /= K; 
    for (int k = 0; k < K; k++)
      topicWords[w][k] -= av; //centered: zero mean
    backgroundWords[w] += av;
  }
  //cout << "func: normalWordWeights-END" <<endl;
}
/// Save a model and predictions to two files
void topicCorpus::save(char* modelPath, char* predictionPath){
  if (modelPath){
	  // topicWords[w][k];
  }
  if (predictionPath){
	// bestValidPredictions[*it]);
  }
}
/// Train a model for "emIterations" with "gradIterations" of gradient descent at each step
void topicCorpus::train(int emIterations, int epoches){
 // cout << "func: train" << endl;
  double bestValid = numeric_limits<double>::max();
  this->epoches = epoches;
  for (int emi = 0; emi < emIterations; emi++)
  {
    for(int epoch = 0; epoch < this->epoches; epoch++){
		random_shuffle(trainUsers.begin(),trainUsers.end());
		random_shuffle(trainBeers.begin(),trainBeers.end());
		
		//cout << "func: train-epoch" << endl;
		int userBatch = trainUsers.size()/numBatches;
		int beerBatch = trainBeers.size()/numBatches;

		for(int batch=1; batch < numBatches; batch++){
			double dkappa = 0;

			vector<double> dbeta_user(nUsers); 
			for (int u = 0; u < nUsers; u ++) 
				dbeta_user[u] = 0;
			vector<double> dbeta_beer(nBeers);
			for (int b = 0; b < nBeers; b ++) 
				dbeta_beer[b] = 0;
			
			vector<vector<double>> dgamma_user(nUsers,vector<double>(K)); 
			for (int u = 0; u < nUsers; u ++)
				std::fill(dgamma_user[u].begin(), dgamma_user[u].end(), 0);
			vector<vector<double>> dgamma_beer(nBeers,vector<double>(K));
			for (int b = 0; b < nBeers; b ++)
				std::fill(dgamma_beer[b].begin(), dgamma_beer[b].end(), 0);

			vector<vector<double>> dimplicit_rating(nBeers, vector<double>(K));
			for (int b = 0; b < nBeers; b++)
				std::fill(dimplicit_rating[b].begin(), dimplicit_rating[b].end(), 0);

			vector<vector<double>> dsocial_h(K, vector<double>(K));
			for (int k = 0; k < K; k++)
				std::fill(dsocial_h[k].begin(), dsocial_h[k].end(), 0); 
			
			vector<vector<double>> dtopicWords(nWords, vector<double>(K));
			for (int w = 0; w < nWords; w++)
				for (int k = 0; k < K; k++)
					dtopicWords[w][k] = 0;

			//cout << "func: train-batch" << endl;
			for (int u = (batch-1)*userBatch; u < batch*userBatch && u < trainUsers.size(); u++){
				for (vector<vote*>::iterator it = trainVotesPerUser[u].begin(); it != trainVotesPerUser[u].end(); it++){
					vote* vi = *it;
					double p = prediction(vi);
					double dl = vi->gWeight * dsquare(p - (vi->value)); // 2*x
					//double dl = dsquare(p - (vi->value - this->overallAverage) ); // 2*x
					dbeta_user[u] += dl;
					for (int k = 0; k < K; k++)
						dgamma_user[u][k] += dl * gamma_beer[vi->item][k]; // gamma_user couples gamma_beer through ratings
			   
					//// implicit feedback from ratings (SVD++)
					int user = vi->user;
					if (trainVotesPerUser[user].size() != 0)
						dl /= sqrt(trainVotesPerUser[user].size());
					for (vector<vote*>::iterator it = trainVotesPerUser[user].begin(); it != trainVotesPerUser[user].end(); it++){
						vote* viNu = *it;
						for (int k = 0; k < K; k++)
							dimplicit_rating[viNu->item][k] += dl * gamma_beer[vi->item][k];
					}
				}
			}
			for (int b = (batch-1)*beerBatch; b < batch*beerBatch && b < trainBeers.size(); b++){
				for (vector<vote*>::iterator it = trainVotesPerBeer[b].begin(); it != trainVotesPerBeer[b].end(); it++){
					vote* vi = *it;
					double p = prediction(vi);
					double dl = vi->gWeight * dsquare(p - (vi->value)); // 2*x
					// dl = dsquare(p - (vi->value - this->overallAverage) ); // 2*x
					dbeta_beer[b] += dl;
					for (int k = 0; k < K; k++)
						dgamma_beer[b][k] += dl * gamma_user[vi->user][k];
					
					//// implicit feedback from ratings (SVD++)
					int user = vi->user;
					if (trainVotesPerUser[user].size() != 0)
						dl /= sqrt(trainVotesPerUser[user].size());
					for (vector<vote*>::iterator it = trainVotesPerUser[user].begin(); it != trainVotesPerUser[user].end(); it++){
						vote* vi = *it;
						int j = vi->item;
						for (int k = 0; k < K; k++)
							dgamma_beer[b][k] += dl * implicit_rating[j][k];
					}
				}
			}
			if (latentUV > 0){
				for (int u = (batch-1)*userBatch; u < batch*userBatch && u < trainUsers.size(); u++){
					for (int k = 0; k < K; k++)
						dgamma_user[u][k] += latentUV * dsquare(gamma_user[u][k]);
				}
				for (int b = (batch-1)*beerBatch; b < batch*beerBatch && b < trainBeers.size(); b++){
					for (int k = 0; k < K; k++)
						dgamma_beer[b][k] += latentUV * dsquare(gamma_beer[b][k]);
				}
				for (int b = (batch - 1)*beerBatch; b < batch*beerBatch && b < trainBeers.size(); b++){
					for (int k = 0; k < K; k++)
						dimplicit_rating[b][k] += latentUV * dsquare(implicit_rating[b][k]);
				}
			}
			if(latentBias > 0){
				for (int u = (batch-1)*userBatch; u < batch*userBatch && u < trainUsers.size(); u++)
					dbeta_user[u] += latentBias * dsquare(beta_user[u]);
				for (int b = (batch-1)*beerBatch; b < batch*beerBatch && b < trainBeers.size(); b++)
					dbeta_beer[b] += latentBias * dsquare(beta_beer[b]);
			 }

			if (this->latentAlpha > 0)  //[LOCABAL, & eSMF] differ here!!!
			{
				for (int u = (batch - 1)*userBatch; u < batch*userBatch; u++){
					map<int, double> neighborSim = this->corp->neighborSimPerUser[u];
					for (map<int, double>::iterator it = neighborSim.begin(); it != neighborSim.end(); it++){
						double sim = predSim(u, it->first);
						double dl = latentAlpha * dsquare(sim - it->second); // 2*x

						//eSMF (factorization Sik; weight by Cik)
						Key key(u, it->first);
						auto itStrength = this->corp->userStrengthMap.find(key);
						if (itStrength != this->corp->userStrengthMap.end())
							dl *= itStrength->second; // rating sim as a weight to social strength

						vector<double> HHu = predHHu(it->first);
						for (int k = 0; k < K; k++)
							dgamma_user[u][k] += dl * HHu[k]; ///!!!

						vector<vector<double>> Huu = predHuu(u, it->first);
						for (int i = 0; i < K; i++)
							for (int j = 0; j < K; j++)
								dsocial_h[i][j] += dl * Huu[i][j]; ///!!!
					}
				}
			}
			if (this->latentAlpha > 0 && latentH > 0){
				for (int i = 0; i < K; i++)
					for (int j = 0; j < K; j++)
						dsocial_h[i][j] += latentH * dsquare(social_h[i][j]);
			}

			 if(this->lambda > 0)
			 {
				for (int b = (batch-1)*beerBatch; b < batch*beerBatch && b < trainBeers.size(); b++){
					double tZ;
					topicZ(b, tZ); // gamma_b is a stocchastic vector, so must be normalized.
					for (int k = 0; k < K; k++){
						double q = -lambda * ( beerTopicCounts[b][k] - beerWords[b]*exp(kappa * gamma_beer[b][k])/tZ );
						dgamma_beer[b][k] += kappa * q;
						dkappa += gamma_beer[b][k] * q;
					}
				}
				double* wZ = new double[K];
				wordZ(wZ);	// topic k's word distribution is a stochastic vector, so must be normalized.
				for (int w = 0; w < nWords; w++)
				  for (int k = 0; k < K; k++)
					dtopicWords[w][k] += -lambda*(wordTopicCounts[w][k] - topicCounts[k]*exp(backgroundWords[w]+topicWords[w][k])/wZ[k]);
				delete[] wZ;
			}

		 //   cout << "func: train-momentum" << endl;
			for (int u = (batch-1)*userBatch; u < batch*userBatch && u < trainUsers.size(); u++)
			  for (int k = 0; k < K; k++)
				gamma_user_inc[u][k] = momentum * gamma_user_inc[u][k] + learingRate * dgamma_user[u][k];
			for (int b = (batch-1)*beerBatch; b < batch*beerBatch && b < trainBeers.size(); b++)
			  for (int k = 0; k < K; k++)
				gamma_beer_inc[b][k] = momentum * gamma_beer_inc[b][k] + learingRate * dgamma_beer[b][k];
			
			for (int b = (batch - 1)*beerBatch; b < batch*beerBatch && b < trainBeers.size(); b++)
			  for (int k = 0; k < K; k++)
				implicit_rating_inc[b][k] = momentum * implicit_rating_inc[b][k] + learingRate * dimplicit_rating[b][k];
			
			if(latentBias > 0)
			{
			  for (int u = (batch-1)*userBatch; u < batch*userBatch && u < trainUsers.size(); u++)
				beta_user_inc[u] = momentum * beta_user_inc[u] + learingRate * dbeta_user[u];
			  for (int b = (batch-1)*beerBatch; b < batch*beerBatch && b < trainBeers.size(); b++)
				beta_beer_inc[b] =  momentum * beta_beer_inc[b] + learingRate * dbeta_beer[b];
			}

			if (this->latentAlpha > 0)
			{
				for (int i = 0; i < K; i++)
					for (int j = 0; j < K; j++)
						social_h_inc[i][j] = momentum * social_h_inc[i][j] + learingRate * dsocial_h[i][j];
			}

			if(this->lambda > 0)
			{
				kappa_inc = momentum * kappa_inc + learingRate * dkappa;
				for (int w = 0; w < nWords; w++)
				  for (int k = 0; k < K; k++)
					topicWords_inc[w][k] = momentum * topicWords_inc[w][k] + learingRate * dtopicWords[w][k];
			}

		//	cout << "func: train-updateGradient" << endl;
			if(latentBias > 0){
			  for (int u = (batch-1)*userBatch; u < batch*userBatch && u < trainUsers.size(); u++)
				beta_user[u] -= beta_user_inc[u];
			  for (int b = (batch-1)*beerBatch; b < batch*beerBatch && b < trainBeers.size(); b++)
				beta_beer[b] -= beta_beer_inc[b];
			}
			for (int u = (batch-1)*userBatch; u < batch*userBatch && u < trainUsers.size(); u++)
			  for (int k = 0; k < K; k++)
				gamma_user[u][k] -= gamma_user_inc[u][k];
			for (int b = (batch-1)*beerBatch; b < batch*beerBatch && b < trainBeers.size(); b++)
			  for (int k = 0; k < K; k++)
				gamma_beer[b][k] -= gamma_beer_inc[b][k];
			
			for (int b = (batch - 1)*beerBatch; b < batch*beerBatch && b < trainBeers.size(); b++)
				for (int k = 0; k < K; k++)
					implicit_rating[b][k] -= implicit_rating_inc[b][k];
			
			if (this->latentAlpha > 0)
			{
				for (int i = 0; i < K; i++)
					for (int j = 0; j < K; j++)
						social_h[i][j] -= social_h_inc[i][j];
			}
			
			if(this->lambda > 0)
			{
				kappa -= kappa_inc;
				for (int w = 0; w < nWords; w++)
				  for (int k = 0; k < K; k++)
					topicWords[w][k] -= topicWords_inc[w][k];
			}
			//cout << "func: train-updateGradient-END" << endl;
		}
		this->eTotal = lsq();
		printf("\n#[Energy(FunVal),eRatings,eRelations,eReviews,eNorms]\n = [%d,%d,%d,%d,%d] After %d grad step: epoch = %d \n", 
			(int)this->eTotal,(int)this->eRatings,(int)this->eRelations,(int)this->eReviews,(int)this->eNorms,emi,epoch);
		double train,valid,test,testSte;
		validTestError(train, valid, test,testSte);
		printf("\nError(RMSE) (train/valid/test) = %f/%f/%f\n", train, valid, test);
		
		//saveUVH();
		if (valid < bestValid){
			bestValid = valid;
			for (vector<vote*>::iterator it = corp->V->begin(); it != corp->V->end(); it++)
				bestValidPredictions[*it] = prediction(*it);
		}
    }//end-epoch
	if (lambda > 0){ //HFT. Update the first time in topicCorpus, then L-BFGS;...
		updateTopics(true);
		normalizeWordWeights();
		//topWords(); //print topic distribution
	}
	//cout << "func:train-Iter = " << emi << endl;
  }//end-iterations
}

int main(int argc, char** argv){

	//srand(0);
	if (argc < 2){
		printf("MR3: 4 files are required: ratingsReviews, relations, weight, and relSoRec\n"); exit(0);
	}
	double latentUV = 0.5;
	double latentBias = 0.5;
	double latentH = 0.5;
	int K = 20; //5~60

	double latentAlpha = 0.01; // 0.001; //social relation regu
	double lambda = 0.001; // 0.05; //review regularization
	{
		string MR3 = "MR3Implicit";
		// printf("Redict stdout to the file 'MR3.txt' in Current Dir.\n");
		//freopen(MR3.c_str(),"w",stdout);
		time_t start = time(NULL);
		printf("corpus(rating+review) = %s\n", argv[1]);
		printf("social relations(cosine) = %s\n", argv[2]);
		printf("global weight(pagerank) = %s\n", argv[3]);
		printf("relSoRec(neighbor) = %s\n", argv[4]);
		printf("latentUV = %f\n", latentUV);
		printf("latentBias = %f\n", latentBias);
		printf("latentH = %f\n", latentH);
		printf("latentAlpha(social regu) = %f\n", latentAlpha);
		printf("lambda(review regu) = %f\n", lambda);
		printf("K = %d\n", K);

		corpus corp(argv[1], argv[2], argv[3], argv[4], 0);
		topicCorpus ec(&corp, K, // K
			latentUV, // low-norm regularization
			latentBias,
			latentH,
			latentAlpha, //social regu
			lambda); // latent topic regularizer
		ec.train(50, 5); // (50,50) emItes = 20, epoches = 10
		// ec.save(modelPath, predictionPath); 
		time_t end = time(NULL);
		double seconds = difftime(end, start);
		printf("Elapsed time = %f(s) or = %f(min)\n", seconds, seconds / 60);
		//  fclose(stdout);
	}

  return 0;
}
