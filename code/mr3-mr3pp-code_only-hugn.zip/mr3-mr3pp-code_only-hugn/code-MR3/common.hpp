#pragma once
#include "common.hpp"
#include "stdio.h"
#include "stdlib.h"
#include "vector"
#include "math.h"
#include <string>
#include <iostream>
#include "map"
#include "set"
#include "vector"
#include "algorithm"
#include "sstream"
#include <fstream>
using namespace std;
/// Safely open a file
FILE* fopen_(const char* p, const char* m){
  FILE* f = fopen(p, m);
  if (!f){
    printf("Failed to open %s\n", p);
    exit(1);
  }
  return f;
}
/// Data associated with a rating
struct vote{
  int user; // ID of the user
  int item; // ID of the item
  float value; // Rating

  std::vector<int> words; // IDs of the words in the review; Maybe empty!

  float gWeight;	//global weight computed by PageRank from social networks

};
typedef struct vote vote;
/// To sort words by frequency in a corpus
bool wordCountCompare(std::pair<std::string, int> p1, std::pair<std::string, int> p2){return p1.second > p2.second;}
/// To sort votes by product ID
bool voteCompare(vote* v1, vote* v2){return v1->item > v2->item;}
/// Sign (-1, 0, or 1)
template<typename T> int sgn(T val){return (val > T(0)) - (val < T(0));}
class corpus{
public:
  corpus(std::string voteFile, string relFile, string weightFile, string relSoRec, int max)
  {
    std::map<std::string, int> uCounts;
    std::map<std::string, int> bCounts;
    std::string uName;
    std::string bName;
    float value;
    int nw;
    int nRead = 0;
    ///1. construct word-freq table
	printf("Read the training file the First time: \n");
	std::ifstream ifs;
	ifs.open(voteFile.c_str(),std::ifstream::in);
    std::string line;
    std::string sWord;
	while (std::getline(ifs,line)){
      std::stringstream ss(line);
	  ss >> uName >> bName >> value >> nw; //No time!
      for (int w = 0; w < nw; w++)	//nw can be zero!
      {
        ss >> sWord;
        if (wordCount.find(sWord) == wordCount.end())
          wordCount[sWord] = 0;
        wordCount[sWord]++;
      }
      if (uCounts.find(uName) == uCounts.end())
        uCounts[uName] = 0;
      if (bCounts.find(bName) == bCounts.end())
        bCounts[bName] = 0;
      uCounts[uName]++;
      bCounts[bName]++;
      nRead++;
      if (nRead % 100000 == 0) {
        printf("R");fflush(stdout);
      }
      if (max > 0 && (int) nRead >= max)
        break;
    }
    ifs.close();
	printf("\nnUsers = %d, nItems = %d, nRatings = %d, #tokens = %d\n", \
		(int) uCounts.size(), (int) bCounts.size(), nRead, wordCount.size() );

    int maxWords = 8000; // Dictionary size 45014
    std::vector < std::pair<std::string, int> > whichWords;
    for (std::map<std::string, int>::iterator it = wordCount.begin(); it != wordCount.end(); it++)
      whichWords.push_back(*it);
    sort(whichWords.begin(), whichWords.end(), wordCountCompare);	//high freq words rank top
	cout << "#total word type = " << whichWords.size();
    if ((int) whichWords.size() < maxWords)
      maxWords = (int) whichWords.size();
	this->nWords = maxWords;
	cout << "; word vocabulary size = " << this->nWords << endl;
	std::ofstream  ofs;
	ofs.open("dict(word-freq).txt",std::ofstream::out);
    for (int w = 0; w < maxWords; w++){
      wordId[whichWords[w].first] = w;
      idWord[w] = whichWords[w].first;
	  ofs << whichWords[w].first << " " <<  whichWords[w].second << std::endl;
    }
	ofs.close();
	///2. fill the data structure V: containing rating matrix and reviews
	printf("Read the trainning file the Second time: \n");
	std::ifstream ifs2;
	ifs2.open(voteFile.c_str(),std::ifstream::in);
	V = new std::vector<vote*>();
	nUsers = 0;
    nBeers = 0;
	int userMin = 0;
    int beerMin = 0;
    nRead = 0;
	vote* v = new vote();
	while (std::getline(ifs2, line)){
      std::stringstream ss(line);
	  ss >> uName >> bName >> value >> nw; //No time!
	  if(value > 5) value = 5;
	  if(value < 0) value = 0;
      for (int w = 0; w < nw; w++) //nw can be zero
      {
        ss >> sWord;
        if (wordId.find(sWord) != wordId.end())
          v->words.push_back(wordId[sWord]);
      }
      if (uCounts[uName] >= userMin) //#ratings the user has rated
      {
        if (userIds.find(uName) == userIds.end()){
          rUserIds[nUsers] = uName;
          userIds[uName] = nUsers++; //starting zero
        }
        v->user = userIds[uName];
      }
      else
        v->user = 0;
      if (bCounts[bName] >= beerMin)
      {
        if (beerIds.find(bName) == beerIds.end()){
          rBeerIds[nBeers] = bName;
          beerIds[bName] = nBeers++;
        }
        v->item = beerIds[bName];
      }
      else
        v->item = 0;
      v->value = value;
      V->push_back(v);
      v = new vote();
      nRead++;
      if (nRead % 100000 == 0){
        printf("R"); fflush( stdout);
      }
      if (max > 0 && (int) nRead >= max)
        break;
    }
    printf("\n");
    delete v;
    ifs2.close();

	vector<vote*>* votesPerUser = new vector<vote*>[nUsers];
	for (vector<vote*>::iterator it = V->begin(); it != V->end(); it++){
		vote* vi = *it;
		votesPerUser[vi->user].push_back(vi);
	}

	printf("\nRead Ratings = %d done. Now read Global weight:\n", nRead);
	ifstream ifg;
	ifg.open(weightFile.c_str(), ifstream::in);
	float gWeight;
	int userName = 0;
	int userId;
	while (getline(ifg, line))
	{
		stringstream ss(line);
		ss >> gWeight;
		userName++;
		userId = userIds[to_string(userName)];
		for (vector<vote*>::iterator it = votesPerUser[userId].begin(); it != votesPerUser[userId].end(); it++)
			(*it)->gWeight = gWeight;
		if (userName % 10000 == 0){
			printf("G");	// global weight
			fflush(stdout);
		}
	}
	ifg.close();
	printf("\n");

	printf("Read Global weights (#users) = %d done. Now read SoRec strength: \n", userName);
	nRead = 0;
	ifstream ifz;
	ifz.open(relSoRec.c_str(), ifstream::in);
	string uName1, uName2;
	int user_i, user_k;
	float strength;
	int countStrength = 0;
	while (getline(ifz, line))
	{
		stringstream ss(line);
		ss >> uName1 >> uName2 >> strength; // SoRec: strength (trust confidence)
		nRead++;
		if (nRead % 70000 == 0) // 435039
		{
			printf("C"); // Social strength Cik
			fflush(stdout);
		}
		user_i = userIds[uName1];
		user_k = userIds[uName2];
		if (user_i == user_k)
			continue;
		Key key(user_i, user_k);
		userStrengthMap.insert(make_pair(key, strength));  //in- & out- degree: asymmetric
		countStrength++;
	}
	ifz.close();
	cout << endl;

	printf("Read social strength  = %d done. Now read LOCABAL relations: \n", countStrength);
	nRead = 0;
	ifstream ifz2;
	ifz2.open(relFile.c_str(), ifstream::in);
	float sim;
	int countSim = 0;
	neighborSimPerUser.resize(nUsers);
	while (getline(ifz2, line))
	{
		stringstream ss(line);
		ss >> uName1 >> uName2 >> sim;
		nRead++;
		if (nRead % 40000 == 0) // 199173
		{
			printf("S"); // Social sim Sik
			fflush(stdout);
		}
		user_i = userIds[uName1];
		user_k = userIds[uName2];
		if (user_i == user_k)
			continue;
		neighborSimPerUser[user_i][user_k] = sim;
		neighborSimPerUser[user_k][user_i] = sim;//rating cosine: symmetric
		countSim += 2;
	}
	ifz2.close();
	cout << "\n#LOCABAL similarity= " << countSim << endl << endl;

	// saveVotes();
  }

  void saveVotes(void) {
    printf("Saving votes = %d:\n", (*V).size() );
    fflush(stdout);
	int nRead = 0;
	FILE *f = fopen_("votes.txt","w");
	for(vector<vote*>::iterator it = V->begin(); it != V->end(); it++){
	  nRead++;
	  if(nRead % 100000 == 0){
		printf("v");fflush(stdout);
	  }
      vote* vi = *it;
	  fprintf(f,"%s %s %f %d ",rUserIds[vi->user].c_str(),rBeerIds[vi->item].c_str(),vi->value,vi->words.size());
	  for(unsigned w=0;w < vi->words.size(); w++) 
		{ fprintf(f,"%s ", (idWord[vi->words[w]]).c_str() ); }
	  fprintf(f,"\n"); 
	}
	fclose(f);
	printf("\n");
  }

  ~corpus(){
    for (std::vector<vote*>::iterator it = V->begin(); it != V->end(); it++)
      delete *it;
    delete V;
  }

  std::vector<vote*>* V;

  typedef pair<int, int> Key;
  typedef map<Key, double> MapPair;
  MapPair userStrengthMap; // SoRec: in- & out- degree

  vector< map<int, double> > neighborSimPerUser; // LOCABAL: local

  int nUsers; // Number of users
  int nBeers; // Number of items
  int nWords; // Number of words
  std::map<std::string, int> userIds; // Maps a user's string-valued ID to an integer
  std::map<std::string, int> beerIds; // Maps an item's string-valued ID to an integer
  std::map<int, std::string> rUserIds; // Inverse of the above map
  std::map<int, std::string> rBeerIds;
  std::map<std::string, int> wordCount; // Frequency of each word in the corpus
  std::map<std::string, int> wordId; // Map each word to its integer ID
  std::map<int, std::string> idWord; // Inverse of the above map
};
