The PNE model is equivalent to an MTNet without the transfer network component, denoted by MTNet_T. 

PNE is also equivalent to a TME without the transfer network component, denoted by TMH\T. 

