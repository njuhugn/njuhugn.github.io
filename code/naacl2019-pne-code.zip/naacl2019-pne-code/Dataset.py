import scipy.sparse as sp
import numpy as np
import sys
from collections import defaultdict

class Dataset(object):

    def __init__(self, dir, path):
        # target domain: interactions and text
        self.trainMatrix = self.load_rating_file_as_matrix(path + ".train.rating")
        self.testRatings = self.load_rating_file_as_list(path + ".valid.rating")
        self.testNegatives = self.load_negative_file(path + ".neg.valid.rating")
        assert len(self.testRatings) == len(self.testNegatives)
        # target: text
        self.vocab = set()
        self.item_context = self.load_item_context(path + '.mult.dat')
        self.num_users, self.num_items = 0, 0

    def load_item_context(self, filename):
        print('read {}...'.format(filename))
        item_context = defaultdict(list)  # sampling with weights/occurrence
        total_freq = 0
        line_no = 1
        with open(filename, "r") as f:
            lines = f.readlines()
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                arr = line.split(" ")
                for w_f in arr[1:]:
                    w, f = w_f.split(':')
                    w = int(w)
                    f = int(f)
                    for _ in range(f):
                        item_context[line_no].append(w)
                    self.vocab.add(w)
                    total_freq += f
                line_no += 1
        print('#item={}, vocab.size = {}, total occurrence = {}'.format(len(item_context),len(self.vocab), total_freq))
        return item_context

    def load_rating_file_as_matrix(self, filename):
        print('read {}...'.format(filename))
        # Get number of users and items
        self.num_users, self.num_items = 0, 0
        with open(filename, "r") as f:
            line = f.readline()
            while line != None and line != "":
                arr = line.split("\t")
                u, i = int(arr[0]), int(arr[1])
                self.num_users = max(self.num_users, u)
                self.num_items = max(self.num_items, i)

                line = f.readline()
        print('maxUserId = {}, maxItemId = {}'.format(self.num_users, self.num_items))

        # Construct matrix
        users_set = set()
        items_set = set()
        mat = sp.dok_matrix((self.num_users+1, self.num_items+1), dtype=np.float32)
        with open(filename, "r") as f:
            line = f.readline()
            while line != None and line != "":
                arr = line.split("\t")
                user, item, rating = int(arr[0]), int(arr[1]), float(arr[2])
                if (rating > 0):
                    mat[user, item] = 1.0
                users_set.add(user)
                items_set.add(item)
                line = f.readline()
        print('#train(user,item,feed)={},{},{}'.format(len(users_set), len(items_set), mat.nnz))
        if self.num_users > 10 * len(users_set) or self.num_items > 10 * len(items_set):
            print('please compress the user_id and item_id to save memory!')
            sys.exit(0)
        return mat

    def load_rating_file_as_list(self, filename):
        print('read {}...'.format(filename))
        users_set = set()
        items_set = set()
        ratingList = []
        with open(filename, "r") as f:
            line = f.readline()
            while line != None and line != "":
                arr = line.split("\t")
                user, item = int(arr[0]), int(arr[1])
                ratingList.append([user, item])
                users_set.add(user)
                items_set.add(item)
                line = f.readline()
        print('#test_pos(user,item,feed)={},{},{}'.format(len(users_set), len(items_set), len(ratingList)))
        return ratingList
    
    def load_negative_file(self, filename):
        print('read {}...'.format(filename))
        negativeList = []
        items_set = set()
        nNegFeed = 0
        with open(filename, "r") as f:
            line = f.readline()
            while line != None and line != "":
                arr = line.split("\t")
                negatives = []
                for x in arr[1:]:  # arr[0] = (user, pos_item)
                    item = int(x)
                    negatives.append(item)
                    items_set.add(item)
                    nNegFeed += 1
                negativeList.append(negatives)
                line = f.readline()
        print('#test_neg(item,feed)={},{}'.format(len(items_set), nNegFeed))
        return negativeList
    

