'''
Eliminating the impact of source domain, i.e. the transfer network, from MTNet
And hence, this is equivalent ot CoMem with a single hidden layer in both MemNet and CFNet
'''
import numpy as np
import tensorflow as tf
from past.builtins import xrange
from Dataset import Dataset
from collections import defaultdict
import time
import sys
import math
import random
import os
from progress.bar import Bar


class ProgressBar(Bar):
    message = 'Loading'
    fill = '#'
    suffix = '%(percent).1f%% | ETA: %(eta)ds'


class MTNet(object):
    def __init__(self, config, sess, train_file, valid_file, valid_neg_file):
        t1 = time.time()
        # target task: interactions & unstructured text
        self.data_dir = config['data_dir']
        self.data_name = config['data_name']
        #self.data_name_source = config['data_name_source']
        dataset = Dataset(self.data_dir, self.data_dir + self.data_name)
        self.train,self.testRatings,self.testNegatives = dataset.trainMatrix,dataset.testRatings,dataset.testNegatives
        self.nUsers, self.nItems = self.train.shape
        print("Load data done [%.1f s]. max_uid=%d, max_iid=%d, #train=%d, #test=%d, #test_neg=%d"
          %(time.time()-t1,self.nUsers,self.nItems,self.train.nnz, len(self.testRatings),len(self.testNegatives)*99))

        self.vocab = dataset.vocab
        self.padding_word_index = len(self.vocab)
        self.vocab.add(self.padding_word_index)  # this word index is for PADDING
        print('vocab.size = {}, padding_word_index = {}'.format(len(self.vocab), self.padding_word_index))

        self.item_context = dataset.item_context  # content text d_ui

        self.users_set = set()
        self.items_set = set()
        self.user_gt_item = defaultdict(int)
        for user, gt_item in self.testRatings:
            self.user_gt_item[user] = gt_item
            self.users_set.add(user)
            self.items_set.add(gt_item)
        print('#users_set = {}'.format(len(self.users_set)))
        print('#items_set = {}'.format(len(self.items_set)))

        # prepare for batch: feed_dict
        self.user_input, self.item_input, self.labels = [],[],[]
        self.test_user_input, self.test_item_input, self.test_labels = [],[],[]

        # hyper-parameters
        self.init_std = config['init_std']
        self.batch_size = config['batch_size']
        self.nepoch = config['nepoch']
        self.edim_u = config['edim_u']
        self.edim_v = config['edim_v']
        self.edim = self.edim_u + self.edim_v
        self.lindim = config['lindim']
        assert self.lindim <= self.edim

        # MemNet
        self.mem_layers = config['mem_layers']
        self.mem_nhop = len(self.mem_layers)  #
        self.mem_size = self.mem_layers[0]
        # CFNet
        self.cf_layers = config['cf_layers']
        self.cf_nhop = len(self.cf_layers)
        self.factors = self.cf_layers[-1]

        self.max_grad_norm = config['max_grad_norm']
        self.negRatio = config['negRatio']
        self.activation = config['activation']
        self.learner = config['learner']
        self.objective = config['objective']
        self.alphas_carry_trans = config['alphas_carry_trans']
        self.carry_alpha = self.alphas_carry_trans[0]
        self.trans_alpha = self.alphas_carry_trans[1]
        self.isScaled = config['isScaled']
        self.scaled_attention = 1.0 / math.sqrt(self.edim)

        self.lambdas_mem_cf = config['lambdas_mem_cf']
        self.mem_lambda = self.lambdas_mem_cf[0]
        self.cf_lambda = self.lambdas_mem_cf[1]

        self.class_size = 2  # positive, negative
        self.input_size = 2  # (user, item)
        # save and restore
        self.show = config['show']
        self.checkpoint_dir = config['checkpoint_dir']

        # target CF
        self.input = tf.placeholder(tf.int32, [self.batch_size, self.input_size], name="input")  # (user, item)
        # target MemNet
        self.local_context = tf.placeholder(tf.int32, [self.batch_size, self.mem_size], name="context")
        # target Label
        self.target = tf.placeholder(tf.float32, [self.batch_size, self.class_size], name="target")

        self.lr = None
        self.init_lr = config['init_lr']
        self.current_lr = config['init_lr']
        self.loss = None
        self.step = None
        self.optim = None

        self.sess = sess
        self.log_loss = []
        self.log_perp = []

        # evaluation
        self.topKs = config['topKs']
        self.length_topKs = len(self.topKs)
        self.HRs = [0.0] * self.length_topKs
        self.NDCGs = [0.0] * self.length_topKs
        self.MRRs = [0.0] * self.length_topKs
        self.HRs_best = [0.0] * self.length_topKs
        self.NDCGs_best = [0.0] * self.length_topKs
        self.MRRs_best = [0.0] * self.length_topKs
        self.HRs_best_epoch = [0] * self.length_topKs
        self.NDCGs_best_epoch = [0] * self.length_topKs
        self.MRRs_best_epoch = [0] * self.length_topKs

        self.evaluation_random_shuffle = config['evaluation_random_shuffle']

        # for post hoc analysis, e.g., the distribution of missed (not hit) users/items, are they cold?
        # only for the cutoff at 10, i.e., topK = 10
        self.missed_users = set()
        self.missed_items = set()
        self.missed_users_best = set()
        self.missed_items_best = set()

    def build_model(self):
        self.global_step = tf.Variable(0, name="global_step")
        # ---------------------------
        # --- model parameters ---
        # embedding matrices for users and items: shared by CFNet and MemNet
        self.U = tf.Variable(tf.random_normal([self.nUsers, self.edim_u], stddev=self.init_std))
        self.V = tf.Variable(tf.random_normal([self.nItems, self.edim_v], stddev=self.init_std))
        # MemNet: embedding matrices
        self.mem_K = tf.Variable(tf.random_normal([len(self.vocab), self.edim], stddev=self.init_std))
        self.mem_V = tf.Variable(tf.random_normal([len(self.vocab), self.edim], stddev=self.init_std))
        self.mem_H = tf.Variable(tf.random_normal([self.edim,self.edim], stddev=self.init_std))  # u^{k+1} = H u^k + o^k
        # CFNet: weights & biases for hidden layers
        self.cf_weights = defaultdict(object)
        self.cf_biases = defaultdict(object)
        for h in xrange(1, self.cf_nhop):  # layer[0]
            self.cf_weights[h] = tf.Variable(tf.random_normal([self.cf_layers[h-1], self.cf_layers[h]], stddev=self.init_std))
            self.cf_biases[h] = tf.Variable(tf.random_normal([self.cf_layers[h]], stddev=self.init_std))

        # Output layer: shared layer
        # joint_rep = [W_mem * o, W_cf * z]
        self.W_mem = tf.Variable(tf.random_normal([self.edim, self.edim], stddev=self.init_std))
        self.W_cf = tf.Variable(tf.random_normal([self.cf_layers[-1], self.cf_layers[-1]], stddev=self.init_std))
        # logit = h * joint_rep + bias
        self.h = tf.Variable(tf.random_normal([self.edim + self.cf_layers[-1], self.class_size], stddev=self.init_std))
        self.b = tf.Variable(tf.random_normal([self.class_size], stddev=self.init_std))
        # ---------------------------
        # --- model architecture ---
        # input & embedding layer
        USERin = tf.nn.embedding_lookup(self.U, self.input[:,0])  # 3D due to batch
        ITEMin = tf.nn.embedding_lookup(self.V, self.input[:,1])
        UIin = tf.concat(values=[USERin, ITEMin], axis=1)  # no info loss, and edim = edim_u + edim_v
        self.UIin2dim = tf.reshape(UIin, [-1, self.edim])
        # MNet
        mem_Kin = tf.nn.embedding_lookup(self.mem_K, self.local_context)  # 3D due to batch
        mem_Vin = tf.nn.embedding_lookup(self.mem_V, self.local_context)
        self.mem_hid_reps = []  # for tracking and analysis
        mem_hid_rep = self.UIin2dim
        self.mem_hid_reps.append(mem_hid_rep)

        # MemNet model
        for h in xrange(self.mem_nhop):
            local_hid3dim = tf.reshape(mem_hid_rep, [-1, 1, self.edim])
            mem_Kout = tf.matmul(local_hid3dim, mem_Kin, adjoint_b=True)  # 1) compute attention: a_i by inner prod
            mem_Kout2dim = tf.reshape(mem_Kout, [-1, self.mem_layers[h]])  # mem_size
            if self.isScaled:  # all you need is attention
                mem_Kout2dim = tf.scalar_mul(self.scaled_attention, mem_Kout2dim)
            ps = tf.nn.softmax(mem_Kout2dim)  # probability vector p_i: over inputs by a softmax
            ps3dim = tf.reshape(ps, [-1, 1, self.mem_layers[h]])
            mem_Vout = tf.matmul(ps3dim, mem_Vin)  # 2) weighted sum by attentive probability
            mem_Vout2dim = tf.reshape(mem_Vout, [-1, self.edim])
            # u^{k+1} = o^k + H u^k
            Carry_out = tf.matmul(mem_hid_rep, self.mem_H)  # linear mapping internal state
            Carry_out_alpha = tf.scalar_mul(self.carry_alpha, Carry_out)
            mem_Vout2dim_alpha = tf.scalar_mul(self.trans_alpha, mem_Vout2dim)
            Dout = tf.add(mem_Vout2dim_alpha, Carry_out_alpha)
            if self.lindim == self.edim:  # No non-linear transformation
                mem_hid_rep = Dout
            elif self.lindim == 0:  # No linear transformation
                if self.activation == 'relu':
                    mem_hid_rep = tf.nn.relu(MVout2dim)
                elif self.activation == 'tanh':
                    mem_hid_rep = tf.tanh(Dout)
                else:
                    mem_hid_rep = tf.sigmoid(Dout)
            else:  # nonlinear + linear transformations
                F = tf.slice(Dout, [0, 0], [self.batch_size, self.lindim])
                G = tf.slice(Dout, [0, self.lindim], [self.batch_size, self.edim-self.lindim])
                if self.activation == 'relu':
                    K = tf.nn.relu(G)
                elif self.activation == 'tanh':
                    K = tf.tanh(G)
                else:
                    K = tf.sigmoid(G)
                mem_hid_rep = tf.concat(axis=1, values=[F, K])
            self.mem_hid_reps.append(mem_hid_rep)

        # CFNet model
        self.cf_hid_reps = []  # for tracking and analysis
        cf_hid_rep = self.UIin2dim
        self.cf_hid_reps.append(cf_hid_rep)
        for h in xrange(1, self.cf_nhop):  # (nhop-1) weights matrix in hidden layers
            cf_hid_rep = tf.add(tf.matmul(cf_hid_rep, self.cf_weights[h]), self.cf_biases[h])
            if self.activation == 'relu':
                cf_hid_rep = tf.nn.relu(cf_hid_rep)
            elif self.activation == 'tanh':
                cf_hid_rep = tf.nn.tanh(cf_hid_rep)
            elif self.activation == 'sigmoid':
                cf_hid_rep = tf.nn.sigmoid(cf_hid_rep)
            self.cf_hid_reps.append(cf_hid_rep)

        # Joint_rep
        mem_rep = tf.matmul(mem_hid_rep, self.W_mem)  # representations from MemNet
        cf_rep = tf.matmul(cf_hid_rep, self.W_cf)  # representations from CFNet
        joint_rep = tf.concat(values=[self.mem_lambda * mem_rep, self.cf_lambda * cf_rep], axis=1)
        # Output
        logit = tf.add(tf.matmul(joint_rep, self.h), self.b)
        self.pred = tf.nn.softmax(logit)

        # optimization
        self.loss = tf.nn.softmax_cross_entropy_with_logits(logits=logit, labels=self.target)
        self.lr = tf.Variable(self.current_lr)
        self.opt = tf.train.AdamOptimizer(self.lr)

        params = [self.U, self.V, self.mem_K, self.mem_V, self.mem_H, self.W_mem, self.W_cf, self.h, self.b]
        for h in range(1, self.cf_nhop):
            params.append(self.cf_weights[h])
            params.append(self.cf_biases[h])
        grads_and_vars = self.opt.compute_gradients(self.loss, params)
        clipped_grads_and_vars = [(tf.clip_by_norm(gv[0], self.max_grad_norm), gv[1]) for gv in grads_and_vars]
        inc = self.global_step.assign_add(1)
        with tf.control_dependencies([inc]):
            self.optim = self.opt.apply_gradients(clipped_grads_and_vars)
        tf.global_variables_initializer().run()

    def get_train_instances(self):
        self.user_input, self.item_input, self.labels = [],[],[]
        for (u, i) in self.train.keys():
            # positive instance
            self.user_input.append(u)
            self.item_input.append(i)
            self.labels.append(1)
            # negative negRatio instances
            for _ in xrange(self.negRatio):
                #j = np.random.randint(self.nItems)
                j = random.randrange(1, self.nItems)  # no id 0
                while (u, j) in self.train:
                    j = random.randrange(1, self.nItems)  # no id 0
                self.user_input.append(u)
                self.item_input.append(j)
                self.labels.append(0)

    def get_test_instances(self):
        self.test_user_input, self.test_item_input, self.test_labels = [],[],[]
        for idx in range(len(self.testRatings)):
            # leave-one-out test_item
            rating = self.testRatings[idx]
            u = rating[0]
            gtItem = rating[1]
            self.test_user_input.append(u)
            self.test_item_input.append(gtItem)
            self.test_labels.append(1)
            # random 99 neg_items
            for i in self.testNegatives[idx]:
                self.test_user_input.append(u)
                self.test_item_input.append(i)
                self.test_labels.append(0)

    def train_model(self):
        self.get_train_instances()  # randomly sample negatives each time

        num_examples = len(self.labels)
        num_batches = int(math.ceil(num_examples / self.batch_size))
        if self.show:
            bar = ProgressBar('train', max=num_batches)
        cost = 0
        x = np.ndarray([self.batch_size, self.input_size], dtype=np.int32)  # (user,item)
        target = np.zeros([self.batch_size, self.class_size])
        local_context = np.ndarray([self.batch_size, self.mem_size])
        for _ in xrange(num_batches):
            if self.show:
                bar.next()
            target.fill(0)
            for b in xrange(self.batch_size):
                sample_id = random.randrange(0, num_examples)
                user = self.user_input[sample_id]
                item = self.item_input[sample_id]
                x[b][0] = user
                x[b][1] = item
                if self.labels[sample_id] == 1:
                    target[b][0] = 1  # one-hot encoding for two classes of positive & negative
                else:
                    target[b][1] = 1  # negative
                # target: text
                if item not in self.item_context:
                    sys.stderr.write('\n this item has no local context: ')
                    sys.stderr.write(str(item))
                    sys.stderr.write('. exit...\n')
                    sys.stdout.flush()
                    sys.exit(0)
                words = self.item_context[item]  # article's words for item x[b][1]
                if self.mem_size <= len(words):
                    local_context[b] = words[:self.mem_size]  # cut off at mem_size
                else:
                    diff = self.mem_size - len(words)
                    for _ in range(diff): words.append(self.padding_word_index)  # padding
                    local_context[b] = words
            keys = [self.input]
            keys.append(self.target)
            keys.append(self.local_context)
            values = [x]
            values.append(target)
            values.append(local_context)
            _, loss, pred, self.step = self.sess.run([self.optim,
                                                self.loss,
                                                self.pred,
                                                self.global_step],
                                                feed_dict={
                                                    k:v for k,v in zip(keys, values)
                                                })
            cost += np.sum(loss)
        if self.show:
            bar.finish()
        return cost/num_batches/self.batch_size

    def run(self):
        self.get_test_instances()  # only need to get once

        time_run_begin = int(time.time())
        self.para_str = 'time'+str(time_run_begin) + '_' + 'eu'+str(self.edim_u)+'ev'+str(self.edim_v) + \
                        'el'+str(self.lindim) + 'm'+str(self.mem_layers) + 'cf'+str(self.cf_layers) + \
                        'b'+str(self.batch_size) + 'lr'+str(self.init_lr) + 'std'+str(self.init_std) + \
                        'nr'+str(self.negRatio) + str(self.activation) + str(self.learner) \
                        + 'loss'+str(self.objective) + 'alpha'+str(self.alphas_carry_trans) + \
                        'scaled'+str(self.isScaled) + 'lambda'+str(self.lambdas_mem_cf)
        print(self.para_str)
        with open('results_' + self.para_str + '.log', 'w') as ofile:
            ofile.write(self.para_str + '\n')
            start_time = time.time()
            for idx in xrange(self.nepoch):
                start = time.time()
                train_loss = np.sum(self.train_model())
                train_time = time.time() - start

                start = time.time()
                valid_loss = np.sum(self.valid_model())
                valid_time = time.time() - start

                for ind in range(len(self.topKs)):
                    topK = self.topKs[ind]

                    if self.HRs[ind] > self.HRs_best[ind]:
                        self.HRs_best[ind] = self.HRs[ind]
                        self.HRs_best_epoch[ind] = idx
                        if topK == 10:
                            self.missed_users_best = self.missed_users
                            self.missed_items_best = self.missed_items

                    if self.NDCGs[ind] > self.NDCGs_best[ind]:
                        self.NDCGs_best[ind] = self.NDCGs[ind]
                        self.NDCGs_best_epoch[ind] = idx
                    if self.MRRs[ind] > self.MRRs_best[ind]:
                        self.MRRs_best[ind] = self.MRRs[ind]
                        self.MRRs_best_epoch[ind] = idx

                print('{:.1f}s, epoch={}, loss={:.6f}, val_l={:.6f}, {:.1f}s'.format(train_time, idx, train_loss, valid_loss, valid_time))
                for ind in range(len(self.topKs)):
                    topK = self.topKs[ind]
                    print('HR={:.6f}, NDCG={:.6f}, MRR={:.6f} at top-{}'.format(self.HRs[ind], self.NDCGs[ind], self.MRRs[ind], topK))

                ofile.write('{:.1f}s, epoch={}, loss={:.6f}, val_l={:.6f}, {:.1f}s\n'.format(train_time, idx, train_loss, valid_loss, valid_time))
                for ind in range(len(self.topKs)):
                    topK = self.topKs[ind]
                    ofile.write('HR={:.6f}, NDCG={:.6f}, MRR={:.6f} at top-{}\n'.format(self.HRs[ind], self.NDCGs[ind], self.MRRs[ind], topK))
                ofile.flush()

            for ind in range(len(self.topKs)):
                topK = self.topKs[ind]
                print('top-{}: '.format(topK))
                print('bestHR = {:.6f} at epoch {}'.format(self.HRs_best[ind], self.HRs_best_epoch[ind]))
                print('bestNDCG = {:.6f} at epoch {}'.format(self.NDCGs_best[ind], self.NDCGs_best_epoch[ind]))
                print('bestMRR = {:.6f} at epoch {}'.format(self.MRRs_best[ind], self.MRRs_best_epoch[ind]))
                if topK == 10:
                    print('#missed_users_best = {}, #missed_items_best = {}'.format(len(self.missed_users_best), len(self.missed_items_best)))

            for ind in range(len(self.topKs)):
                topK = self.topKs[ind]
                ofile.write('top-{}: \n'.format(topK))
                ofile.write('bestHR = {:.6f} at epoch {}\n'.format(self.HRs_best[ind], self.HRs_best_epoch[ind]))
                ofile.write('bestNDCG = {:.6f} at epoch {}\n'.format(self.NDCGs_best[ind], self.NDCGs_best_epoch[ind]))
                ofile.write('bestMRR = {:.6f} at epoch {}\n'.format(self.MRRs_best[ind], self.MRRs_best_epoch[ind]))
                if topK == 10:
                    ofile.write('#missed_users_best = {}, #missed_items_best = {}\n'.format(len(self.missed_users_best), len(self.missed_items_best)))

            print('total time = {:.1f}m'.format((time.time() - start_time)/60))
            ofile.write('total time = {:.1f}\n'.format((time.time() - start_time)/60))

        with open('time'+str(time_run_begin) + 'missed_users_best.list', 'w') as ofile:
            ofile.write('\n'.join([str(u) for u in self.missed_users_best]))

        with open('time'+str(time_run_begin) + 'missed_items_best.list', 'w') as ofile:
            ofile.write('\n'.join([str(i) for i in self.missed_items_best]))

        print(self.para_str)

    def valid_model(self):
        num_test_examples = len(self.test_labels)
        num_test_batches = math.ceil(num_test_examples / self.batch_size)
        if self.show:
            bar = ProgressBar('valid', max=num_test_batches)
        cost = 0
        x = np.ndarray([self.batch_size, self.input_size], dtype=np.int32)  # user, item
        target = np.zeros([self.batch_size, self.class_size])
        local_context = np.ndarray([self.batch_size, self.mem_size])
        sample_id = 0
        test_preds = []
        user_item_preds = defaultdict(lambda: defaultdict(float))
        for current_batch in xrange(num_test_batches):
            if self.show:
                bar.next()
            target.fill(0)
            for b in xrange(self.batch_size):
                if sample_id >= len(self.test_labels):  # fill this batch,will not be used when compute test performance
                    x[b][0] = self.test_user_input[0]
                    x[b][1] = self.test_item_input[0]
                    if self.test_labels[0] == 1:
                        target[b][0] = 1  # one-hot encoding for two classes of positive & negative
                    else:
                        target[b][1] = 1  # negative
                    words = self.item_context[x[b][1]]
                    w = random.randrange(0, len(words))
                    local_context[b] = words[w]
                else:
                    user = self.test_user_input[sample_id]
                    item = self.test_item_input[sample_id]
                    x[b][0] = user
                    x[b][1] = item
                    if self.test_labels[sample_id] == 1:
                        target[b][0] = 1  # one-hot encoding for two classes of positive & negative
                    else:
                        target[b][1] = 1  # negative
                    words = self.item_context[item]
                    if self.mem_size <= len(words):
                        local_context[b] = words[:self.mem_size]  # cut off at mem_size
                    else:
                        diff = self.mem_size - len(words)
                        for _ in range(diff): words.append(self.padding_word_index)  # padding
                        local_context[b] = words
                sample_id += 1
            keys = [self.input]
            keys.append(self.target)
            keys.append(self.local_context)
            values = [x]
            values.append(target)
            values.append(local_context)
            loss, pred = self.sess.run([self.loss, self.pred],
                                                feed_dict={
                                                    k:v for k,v in zip(keys, values)
                                                })
            cost += np.sum(loss)
            test_preds.extend(pred)
        if self.show:
            bar.finish()

        # evaluation
        for sample_id in range(len(self.test_labels)):
            user = self.test_user_input[sample_id]
            item = self.test_item_input[sample_id]
            label = self.test_labels[sample_id]
            pred = test_preds[sample_id]  # [[pred1][pred2]...[]]
            user_item_preds[user][item] = pred[0]

        HRs = [0.0] * self.length_topKs
        NDCGs = [0.0] * self.length_topKs
        MRRs = [0.0] * self.length_topKs
        hit10_users = set()
        hit10_items = set()
        for user, item_preds in user_item_preds.items():
            # this is important otherwise the gt_item will rank highest when their prediction scores are equal
            if self.evaluation_random_shuffle:
                i_ps = []
                for i, p in item_preds.items():
                    i_ps.append([i, p])
                random.shuffle(i_ps)
                item_preds = i_ps
                item_preds = sorted(item_preds, key=lambda x:-x[1])
            else:
                item_preds = sorted(item_preds.items(), key=lambda x:-x[1])

            is_valid = False
            pred_rank_gt = 0
            pred_gt = 0
            for item, pred in item_preds:
                pred_gt = pred
                if item == self.user_gt_item[user]:
                    is_valid = True
                    break
                pred_rank_gt += 1

            if not is_valid:
                print('is_valid = {}. exit...'.format(is_valid))

            #if user % 1000 == 0: print('rank = {}, pred = {}'.format(pred_rank_gt, pred_gt))

            for ind in range(len(self.topKs)):
                topK = self.topKs[ind]
                if pred_rank_gt < topK:
                    HRs[ind] += 1
                    NDCGs[ind] += math.log(2) / math.log(pred_rank_gt + 2)
                    MRRs[ind] += 1.0 / (pred_rank_gt + 1)
                    if topK == 10:
                        hit10_users.add(user)
                        hit10_items.add(self.user_gt_item[user])

        print('#hit10_users = {}'.format(len(hit10_users)))
        print('#hit10_items = {}'.format(len(hit10_items)))

        for ind in range(len(self.topKs)):
            HRs[ind] /= self.nUsers
            NDCGs[ind] /= self.nUsers
            MRRs[ind] /= self.nUsers

        # reset and update
        self.HRs = HRs
        self.NDCGs = NDCGs
        self.MRRs = MRRs

        self.missed_users = self.users_set.difference(hit10_users)
        self.missed_items = self.items_set.difference(hit10_items)

        print('#missed_users = {}'.format(len(self.missed_users)))
        print('#missed_items = {}'.format(len(self.missed_items)))

        return cost/num_test_batches/self.batch_size
