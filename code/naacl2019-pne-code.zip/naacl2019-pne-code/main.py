'''
Eliminating the impact of source domain, i.e. the transfer network, from MTNet
And hence, this is equivalent ot CoMem with a single hidden layer in both MemNet and CFNet
'''

import pprint
import tensorflow as tf
import time
from model import MTNet
pp = pprint.PrettyPrinter()


paras_setting = {
    #'edim_u': 20,  # "internal state dimension of user "
    #'edim_v': 10,  # "internal state dimension of item "
    'edim_u': 75,  # "internal state dimension: user [150]"
    'edim_v': 75,  # "internal state dimension: item [150]"
    #'edim': ?,  # "internal state dimension: user + item [150]"
    'lindim': 75,  # "linear part of the state [75]"
    #'mem_size': 50,  # "memory size [100]"
    #'nhop': 3,  # "the hops are nonlinear [True]"
    'mem_layers': [100],  # MemNet for unstructured text. Note: one hop = <key,value> pair
    'cf_layers': [150, 50],  # CFNet for interactions. Note: cf_layers[0] == edim_u + edim_v
    #'tl_layers': [75, 50],  # TLNet for cross-domain transfer. Note: tl_layers[0] == edim_v
    'batch_size': 128,  # "batch size to use during training [64,128,256,512,1024,2048,4096,8192]"
    'nepoch': 100,  # "number of epoch to use during training [80]"
    'init_lr': 0.001,  # "initial learning rate [0.01]"
    'init_std': 0.01,  # "weight initialization std [0.05]"
    'max_grad_norm': 50,  # "clip gradients to this norm [50]"
    'negRatio': 1,  # "negative sampling ratio [5]"
    #'merge_ui': 0,  # "merge embeddings of user and item: 0-add, 1-mult [1], 2-concat"
    'activation': 'relu',  # "0:relu, 1:tanh, 2:sigmoid"
    'learner': 'adam',  # {adam, rmsprop, adagrad, sgd}
    'objective': 'cross',  # 0:cross, 1: hinge, 2:log
    'alphas_carry_trans': [0.5, 0.5],  # u^{k+1} = trans_alpha * o^k + carry_alpha * H u^k
    'lambdas_mem_cf': [0.5, 0.5],  # [0.3-0.5] joint_rep = lambda * W * hid
    #'lambdas_mem_cf_tl': [0.3, 0.4, 0.3],  # [0.3-0.5] joint_rep = lambda * W * hid
    'isScaled': True,  # scaled dot-product attention, see "attention is all you need"
    'topKs': [1, 5, 10, 20],
    'data_dir': '../data/',  # "data directory [../data]"
    'data_name': 'NY_news',  # target: interactions & text
    #'data_name_source': 'NY_app',  # target:
    'checkpoint_dir': 'checkpoints',  # "checkpoints", "checkpoint directory [checkpoints]"
    'show': True,  # "print progress [True]"
    'evaluation_random_shuffle': False,
}

start_time = time.time()
pp.pprint(paras_setting)

train_file = paras_setting['data_dir'] + paras_setting['data_name'] + '.train'
valid_file = paras_setting['data_dir'] + paras_setting['data_name'] + '.valid'
valid_neg_file = paras_setting['data_dir'] + paras_setting['data_name'] + '.neg.valid'
with tf.Session() as sess:
    model = MTNet(paras_setting, sess, train_file, valid_file, valid_neg_file)
    model.build_model()
    model.run()
    for ind in range(len(model.topKs)):
        topK = model.topKs[ind]
        print('top-{}: '.format(topK))
        print('bestHR = {:.6f} at epoch {}'.format(model.HRs_best[ind], model.HRs_best_epoch[ind]))
        print('bestNDCG = {:.6f} at epoch {}'.format(model.NDCGs_best[ind], model.NDCGs_best_epoch[ind]))
        print('bestMRR = {:.6f} at epoch {}'.format(model.MRRs_best[ind], model.MRRs_best_epoch[ind]))
    print(model.para_str)
    pp.pprint(paras_setting)
print('total time {:.2f}m'.format((time.time() - start_time)/60))
